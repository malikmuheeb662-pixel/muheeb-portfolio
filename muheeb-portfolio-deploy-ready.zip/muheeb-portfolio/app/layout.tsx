import type { Metadata } from "next";
import "./globals.css";

const TITLE = "Muheeb Malik — Digital Growth & Creative Professional";
const DESCRIPTION =
  "Portfolio of Muheeb Malik — digital growth, web development, SEO, performance marketing, e-commerce and creative projects.";

export const metadata: Metadata = {
  title: TITLE,
  description: DESCRIPTION,
  openGraph: {
    title: TITLE,
    description: DESCRIPTION,
    type: "website",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className="h-full antialiased">
      <body className="min-h-full bg-[#050505] font-sans text-white">{children}</body>
    </html>
  );
}
