"use client";

import { useState } from "react";
import LoadingScreen from "@/components/loading/LoadingScreen";
import Navbar from "@/components/navigation/Navbar";
import FullscreenMenu from "@/components/navigation/FullscreenMenu";
import Experience from "@/components/experience/Experience";

export default function Home() {
  const [entered, setEntered] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <main className="relative min-h-screen w-full bg-[#050505]">
      {!entered && <LoadingScreen onEnter={() => setEntered(true)} />}

      <Navbar onMenuClick={() => setMenuOpen(true)} visible={entered} />
      <FullscreenMenu open={menuOpen} onClose={() => setMenuOpen(false)} />

      <Experience entered={entered} />
    </main>
  );
}
