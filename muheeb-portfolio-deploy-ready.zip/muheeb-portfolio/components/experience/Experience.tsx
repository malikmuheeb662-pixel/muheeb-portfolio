"use client";

import { useEffect, useRef } from "react";
import dynamic from "next/dynamic";
import Hero from "@/components/hero/Hero";
import AboutSection from "@/components/sections/AboutSection";
import SkillsSection from "@/components/sections/SkillsSection";
import WorkSection from "@/components/sections/WorkSection";
import JourneyTimeline from "@/components/sections/JourneyTimeline";
import CertificationGrid from "@/components/sections/CertificationGrid";
import ResumeSection from "@/components/sections/ResumeSection";
import ContactSection from "@/components/sections/ContactSection";
import FinalCTA from "@/components/sections/FinalCTA";
import CaseStudyOverlay from "@/components/sections/CaseStudyOverlay";
import StaticFallbackBackground from "@/components/three/StaticFallbackBackground";
import { ExperienceProvider, useExperience } from "./ExperienceContext";
import { useScrollProgress } from "@/hooks/useScrollProgress";
import { useReducedMotion } from "@/hooks/useReducedMotion";
import { useIsMobile } from "@/hooks/useIsMobile";
import { useWebGLSupport } from "@/hooks/useWebGLSupport";
import {
  HERO_VH,
  ABOUT_VH,
  SKILLS_VH,
  WORK_VH,
  JOURNEY_VH,
  CERTS_VH,
  RESUME_VH,
  CONTACT_VH,
  FINAL_VH,
  HERO_END,
  ABOUT_END,
  WORK_END,
  JOURNEY_END,
  computeZoneOpacities,
  computeLocalProgress,
} from "@/lib/zones";

const Scene = dynamic(() => import("@/components/three/Scene"), { ssr: false });

/**
 * The single coordinated Hero -> About -> Skills -> Work -> Journey ->
 * Certifications -> Resume -> Contact -> Final CTA experience, plus the
 * case-study overlay. One tall scroll container, one pinned Canvas shared
 * by every zone and every case study — reusing the Phase 1-5 scroll/camera/
 * mobile/reduced-motion/WebGL-fallback architecture rather than spinning up
 * separate sections or canvases.
 */
export default function Experience({ entered }: { entered: boolean }) {
  return (
    <ExperienceProvider>
      <ExperienceInner entered={entered} />
    </ExperienceProvider>
  );
}

function ExperienceInner({ entered }: { entered: boolean }) {
  const { openCaseStudy, setOpenCaseStudy } = useExperience();
  const scrollProgress = useRef(0);
  const caseStudyProgress = useRef(0);
  const progress = useScrollProgress();
  const reducedMotion = useReducedMotion();
  const isMobile = useIsMobile();
  const webglSupported = useWebGLSupport();

  useEffect(() => {
    scrollProgress.current = progress;
  }, [progress]);

  const zoneOpacities = computeZoneOpacities(progress);
  const aboutLocalProgress = computeLocalProgress(progress, HERO_END, ABOUT_END);
  const journeyLocalProgress = computeLocalProgress(progress, WORK_END, JOURNEY_END);

  return (
    <>
      {/* Background content is inert while a case study overlay is open —
          it's still there (so closing restores it instantly) but neither
          visible focus targets nor pointer events should reach it. */}
      <div aria-hidden={openCaseStudy ? true : undefined} style={openCaseStudy ? { pointerEvents: "none" } : undefined}>
        {webglSupported === false ? (
          <div className="relative w-full bg-[#050505]">
            <section id="home" className="relative min-h-screen w-full overflow-hidden">
              <StaticFallbackBackground />
              <div className="relative z-10 h-screen">
                <Hero entered={entered} reducedMotion={reducedMotion} interactive={false} />
              </div>
            </section>
            <section className="relative min-h-screen w-full overflow-hidden">
              <StaticFallbackBackground />
              <div className="relative z-10 min-h-screen py-20">
                <AboutSection localProgress={1} />
              </div>
            </section>
            <section className="relative min-h-screen w-full overflow-hidden">
              <StaticFallbackBackground />
              <div className="relative z-10 min-h-screen py-20">
                <SkillsSection />
              </div>
            </section>
            <section className="relative min-h-screen w-full overflow-hidden">
              <StaticFallbackBackground />
              <div className="relative z-10 min-h-screen py-20">
                <WorkSection />
              </div>
            </section>
            <section className="relative min-h-screen w-full overflow-hidden">
              <StaticFallbackBackground />
              <div className="relative z-10 min-h-screen py-20">
                <JourneyTimeline localProgress={1} />
              </div>
            </section>
            <section className="relative min-h-screen w-full overflow-hidden">
              <StaticFallbackBackground />
              <div className="relative z-10 min-h-screen py-20">
                <CertificationGrid />
              </div>
            </section>
            <section className="relative min-h-screen w-full overflow-hidden">
              <StaticFallbackBackground />
              <div className="relative z-10 min-h-screen py-20">
                <ResumeSection />
              </div>
            </section>
            <section className="relative min-h-screen w-full overflow-hidden">
              <StaticFallbackBackground />
              <div className="relative z-10 min-h-screen py-20">
                <ContactSection />
              </div>
            </section>
            <section className="relative min-h-screen w-full overflow-hidden">
              <StaticFallbackBackground />
              <div className="relative z-10 flex min-h-screen flex-col py-20">
                <FinalCTA />
              </div>
            </section>
          </div>
        ) : (
          <div
            className="relative w-full"
            style={{
              height: `${
                HERO_VH +
                ABOUT_VH +
                SKILLS_VH +
                WORK_VH +
                JOURNEY_VH +
                CERTS_VH +
                RESUME_VH +
                CONTACT_VH +
                FINAL_VH
              }vh`,
            }}
          >
            <div className="sticky top-0 h-screen w-full overflow-hidden bg-[#050505]">
              <div className="absolute inset-0">
                <Scene
                  scrollProgress={scrollProgress}
                  reducedMotion={reducedMotion}
                  isMobile={isMobile}
                  zoneOpacities={zoneOpacities}
                  aboutLocalProgress={aboutLocalProgress}
                  journeyLocalProgress={journeyLocalProgress}
                  caseStudyId={openCaseStudy}
                  caseStudyProgress={caseStudyProgress}
                />
              </div>

              <div
                className="absolute inset-0"
                style={{
                  opacity: zoneOpacities.hero,
                  pointerEvents: zoneOpacities.hero > 0.5 ? "auto" : "none",
                }}
              >
                <Hero
                  entered={entered}
                  reducedMotion={reducedMotion}
                  interactive={zoneOpacities.hero > 0.5}
                />
              </div>

              <div
                className="absolute inset-0"
                style={{
                  opacity: zoneOpacities.about,
                  pointerEvents: zoneOpacities.about > 0.5 ? "auto" : "none",
                }}
              >
                <AboutSection localProgress={aboutLocalProgress} />
              </div>

              <div
                className="absolute inset-0"
                style={{
                  opacity: zoneOpacities.skills,
                  pointerEvents: zoneOpacities.skills > 0.5 ? "auto" : "none",
                }}
              >
                <SkillsSection />
              </div>

              <div
                className="absolute inset-0"
                style={{
                  opacity: zoneOpacities.work,
                  pointerEvents: zoneOpacities.work > 0.5 ? "auto" : "none",
                }}
              >
                <WorkSection />
              </div>

              <div
                className="absolute inset-0"
                style={{
                  opacity: zoneOpacities.journey,
                  pointerEvents: zoneOpacities.journey > 0.5 ? "auto" : "none",
                }}
              >
                <JourneyTimeline localProgress={journeyLocalProgress} />
              </div>

              <div
                className="absolute inset-0"
                style={{
                  opacity: zoneOpacities.certifications,
                  pointerEvents: zoneOpacities.certifications > 0.5 ? "auto" : "none",
                }}
              >
                <CertificationGrid />
              </div>

              <div
                className="absolute inset-0"
                style={{
                  opacity: zoneOpacities.resume,
                  pointerEvents: zoneOpacities.resume > 0.5 ? "auto" : "none",
                }}
              >
                <ResumeSection />
              </div>

              <div
                className="absolute inset-0"
                style={{
                  opacity: zoneOpacities.contact,
                  pointerEvents: zoneOpacities.contact > 0.5 ? "auto" : "none",
                }}
              >
                <ContactSection />
              </div>

              <div
                className="absolute inset-0"
                style={{
                  opacity: zoneOpacities.finalCta,
                  pointerEvents: zoneOpacities.finalCta > 0.5 ? "auto" : "none",
                }}
              >
                <FinalCTA />
              </div>
            </div>
          </div>
        )}
      </div>

      {openCaseStudy && (
        <CaseStudyOverlay
          projectId={openCaseStudy}
          onClose={() => setOpenCaseStudy(null)}
          onOpenProject={(id) => setOpenCaseStudy(id)}
          webglSupported={webglSupported}
          reducedMotion={reducedMotion}
          progressRef={caseStudyProgress}
        />
      )}
    </>
  );
}
