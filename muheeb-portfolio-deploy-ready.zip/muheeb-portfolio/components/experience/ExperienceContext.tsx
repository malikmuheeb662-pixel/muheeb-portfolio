"use client";

import { createContext, useContext, useMemo, useState, ReactNode } from "react";
import type { ProjectId } from "@/lib/caseStudies";

interface ExperienceContextValue {
  hoveredCluster: string | null;
  setHoveredCluster: (id: string | null) => void;
  hoveredProject: string | null;
  setHoveredProject: (id: string | null) => void;
  selectedProject: string | null;
  setSelectedProject: (id: string | null) => void;
  openCaseStudy: ProjectId | null;
  setOpenCaseStudy: (id: ProjectId | null) => void;
  hoveredMilestone: string | null;
  setHoveredMilestone: (id: string | null) => void;
}

const ExperienceContext = createContext<ExperienceContextValue | null>(null);

/**
 * Shares interaction state between DOM cards (skill clusters, project cards)
 * and their corresponding 3D nodes rendered inside the Canvas, so hovering
 * or focusing a card reacts in the 3D world without prop-drilling through
 * the Canvas boundary. Context providers above <Canvas /> are visible inside
 * it in React Three Fiber, so this works across both trees.
 *
 * hoveredProject is transient (mouse hover / keyboard focus); selectedProject
 * persists after a click/Enter activation until toggled again — the Work
 * section's "focus state" from the Phase 3 spec.
 */
export function ExperienceProvider({ children }: { children: ReactNode }) {
  const [hoveredCluster, setHoveredCluster] = useState<string | null>(null);
  const [hoveredProject, setHoveredProject] = useState<string | null>(null);
  const [selectedProject, setSelectedProject] = useState<string | null>(null);
  const [openCaseStudy, setOpenCaseStudy] = useState<ProjectId | null>(null);
  const [hoveredMilestone, setHoveredMilestone] = useState<string | null>(null);

  const value = useMemo(
    () => ({
      hoveredCluster,
      setHoveredCluster,
      hoveredProject,
      setHoveredProject,
      selectedProject,
      setSelectedProject,
      openCaseStudy,
      setOpenCaseStudy,
      hoveredMilestone,
      setHoveredMilestone,
    }),
    [hoveredCluster, hoveredProject, selectedProject, openCaseStudy, hoveredMilestone]
  );

  return <ExperienceContext.Provider value={value}>{children}</ExperienceContext.Provider>;
}

export function useExperience() {
  const ctx = useContext(ExperienceContext);
  if (!ctx) {
    throw new Error("useExperience must be used within an ExperienceProvider");
  }
  return ctx;
}
