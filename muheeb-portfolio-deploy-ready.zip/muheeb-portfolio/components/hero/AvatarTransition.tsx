"use client";

/**
 * Architecture for the future 3D Avatar <-> Real Photo seamless transformation.
 * Currently the 3D avatar lives inside the R3F <Scene />; this component reserves
 * the DOM-layer slot for the eventual real-photo state and the crossfade between
 * the two, so a later phase can wire up scroll- or click-triggered morphing
 * without restructuring the hero.
 */
interface AvatarTransitionProps {
  progress?: number; // 0 = full 3D avatar, 1 = full real photo
  photoSrc?: string; // placeholder until Muheeb's real photo is supplied
}

export default function AvatarTransition({ progress = 0, photoSrc }: AvatarTransitionProps) {
  return (
    <div
      className="pointer-events-none absolute inset-0 flex items-center justify-center"
      style={{ opacity: progress }}
      aria-hidden={progress === 0}
    >
      {photoSrc ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img
          src={photoSrc}
          alt="Muheeb Malik"
          className="h-[60vh] w-auto object-contain opacity-90"
        />
      ) : (
        <div className="h-[40vh] w-[28vh] rounded-3xl border border-dashed border-white/10" />
      )}
    </div>
  );
}
