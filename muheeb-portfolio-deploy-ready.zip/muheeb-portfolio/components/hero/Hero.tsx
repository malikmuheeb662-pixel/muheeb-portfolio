"use client";

import HeroContent from "./HeroContent";
import AvatarTransition from "./AvatarTransition";

interface HeroProps {
  entered: boolean;
  reducedMotion?: boolean;
  interactive?: boolean;
}

/**
 * The Hero zone's DOM content only. The 3D (particles, avatar, digital
 * objects) now lives in the shared <Scene /> owned by <Experience />, so this
 * component no longer creates its own Canvas or sticky wrapper — it's just
 * one of three DOM overlays that crossfade over the single pinned universe.
 */
export default function Hero({ entered, reducedMotion = false, interactive = true }: HeroProps) {
  return (
    <div className="relative h-full w-full">
      {/* Reserved slot for the future 3D avatar <-> real photo morph. */}
      <AvatarTransition progress={0} />

      <div className="absolute inset-0 flex items-center">
        <HeroContent play={entered} reducedMotion={reducedMotion} />
      </div>

      {interactive && (
        <div className="absolute bottom-8 left-1/2 flex -translate-x-1/2 flex-col items-center gap-2 text-zinc-500">
          <span className="text-[10px] tracking-[0.3em]">SCROLL TO EXPLORE</span>
          <span className="h-8 w-px animate-pulse bg-gradient-to-b from-zinc-500 to-transparent" />
        </div>
      )}
    </div>
  );
}
