"use client";

import { useEffect, useRef } from "react";
import gsap from "gsap";
import MagneticButton from "@/components/ui/MagneticButton";
import { HERO_COPY } from "@/lib/constants";
import { scrollToZone } from "@/lib/zones";

export default function HeroContent({
  play,
  reducedMotion = false,
}: {
  play: boolean;
  reducedMotion?: boolean;
}) {
  const eyebrowRef = useRef<HTMLParagraphElement>(null);
  const headingRef = useRef<HTMLHeadingElement>(null);
  const supportRef = useRef<HTMLParagraphElement>(null);
  const ctaRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!play) return;

    if (reducedMotion) {
      // Skip the choreographed reveal; just show everything immediately.
      gsap.set(
        [eyebrowRef.current, headingRef.current?.querySelectorAll(".line"), supportRef.current, ctaRef.current],
        { opacity: 1, y: 0 }
      );
      return;
    }

    const tl = gsap.timeline({ delay: 0.2 });
    tl.fromTo(eyebrowRef.current, { opacity: 0, y: 12 }, { opacity: 1, y: 0, duration: 0.6, ease: "power3.out" })
      .fromTo(
        headingRef.current?.querySelectorAll(".line") ?? [],
        { opacity: 0, y: 30 },
        { opacity: 1, y: 0, duration: 0.7, ease: "power3.out", stagger: 0.1 },
        "-=0.2"
      )
      .fromTo(supportRef.current, { opacity: 0, y: 12 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, "-=0.3")
      .fromTo(ctaRef.current, { opacity: 0, y: 12 }, { opacity: 1, y: 0, duration: 0.5, ease: "power3.out" }, "-=0.3");
  }, [play, reducedMotion]);

  return (
    <div className="relative z-10 mx-auto flex max-w-3xl flex-col items-start gap-6 px-6 text-left">
      <p
        ref={eyebrowRef}
        className="text-xs sm:text-sm tracking-[0.3em] text-zinc-400 opacity-0"
      >
        {HERO_COPY.eyebrow}
      </p>

      <h1
        ref={headingRef}
        className="text-4xl font-semibold leading-tight tracking-tight text-white sm:text-6xl lg:text-7xl"
      >
        <span className="line block overflow-hidden">I BUILD DIGITAL</span>
        <span className="line block overflow-hidden">EXPERIENCES THAT</span>
        <span className="line block overflow-hidden bg-gradient-to-r from-[#8B5CF6] via-[#A855F7] to-[#D946EF] bg-clip-text text-transparent">
          HELP BRANDS GROW.
        </span>
      </h1>

      <p ref={supportRef} className="text-sm sm:text-base text-zinc-400 opacity-0">
        {HERO_COPY.supporting}
      </p>

      <div ref={ctaRef} className="mt-2 flex flex-wrap items-center gap-4 opacity-0">
        <MagneticButton href="#work" variant="primary" onClick={() => scrollToZone("work")}>
          {HERO_COPY.primaryCta} →
        </MagneticButton>
        <MagneticButton href="#resume" variant="secondary" onClick={() => scrollToZone("resume")}>
          {HERO_COPY.secondaryCta} ↗
        </MagneticButton>
      </div>
    </div>
  );
}
