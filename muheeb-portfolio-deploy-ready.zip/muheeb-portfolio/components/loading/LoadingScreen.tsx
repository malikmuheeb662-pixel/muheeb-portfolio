"use client";

import { useEffect, useRef, useState } from "react";
import gsap from "gsap";
import { useReducedMotion } from "@/hooks/useReducedMotion";

interface LoadingScreenProps {
  onEnter: () => void;
}

interface Particle {
  top: number;
  left: number;
  opacity: number;
  duration: number;
  delay: number;
}

export default function LoadingScreen({ onEnter }: LoadingScreenProps) {
  const [progress, setProgress] = useState(0);
  const [ready, setReady] = useState(false);
  const [exiting, setExiting] = useState(false);
  // Particles start as null so the server-rendered HTML and the first client
  // render match exactly; they're generated client-side after mount, avoiding
  // a hydration mismatch from Math.random() differing between server/client.
  const [particles, setParticles] = useState<Particle[] | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const glowRef = useRef<HTMLDivElement>(null);
  const particlesRef = useRef<HTMLDivElement>(null);
  const reducedMotion = useReducedMotion();

  useEffect(() => {
    // eslint-disable-next-line react-hooks/set-state-in-effect -- one-time client-only randomization after mount, deliberately generated post-hydration (see comment above)
    setParticles(
      Array.from({ length: 40 }, () => ({
        top: Math.random() * 100,
        left: Math.random() * 100,
        opacity: Math.random() * 0.6 + 0.2,
        duration: 4 + Math.random() * 4,
        delay: Math.random() * 3,
      }))
    );
  }, []);

  useEffect(() => {
    let raf: number;
    const start = performance.now();
    const duration = reducedMotion ? 400 : 1800;

    function tick(now: number) {
      const t = Math.min((now - start) / duration, 1);
      setProgress(Math.floor(t * 100));
      if (t < 1) {
        raf = requestAnimationFrame(tick);
      } else {
        setReady(true);
      }
    }
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [reducedMotion]);

  function handleEnter() {
    if (exiting) return;
    setExiting(true);

    if (reducedMotion) {
      // Skip the cinematic expansion entirely; a quick fade is enough.
      gsap.to(containerRef.current, {
        opacity: 0,
        duration: 0.25,
        ease: "power1.inOut",
        onComplete: onEnter,
      });
      return;
    }

    const tl = gsap.timeline({ onComplete: onEnter });

    tl.to(glowRef.current, {
      scale: 40,
      opacity: 1,
      duration: 1.1,
      ease: "power2.in",
    })
      .to(
        particlesRef.current,
        { opacity: 0, duration: 0.6, ease: "power1.in" },
        "-=0.9"
      )
      .to(
        containerRef.current,
        { opacity: 0, duration: 0.6, ease: "power1.inOut" },
        "-=0.4"
      );
  }

  return (
    <div
      ref={containerRef}
      className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-[#050505] overflow-hidden"
    >
      <div
        ref={particlesRef}
        className="pointer-events-none absolute inset-0 transition-opacity duration-1000"
        style={{ opacity: particles && progress > 15 ? 0.5 : 0 }}
      >
        {particles?.map((p, i) => (
          <span
            key={i}
            className="absolute h-[2px] w-[2px] rounded-full bg-[#A855F7]"
            style={{
              top: `${p.top}%`,
              left: `${p.left}%`,
              opacity: p.opacity,
              animation: reducedMotion
                ? "none"
                : `floaty ${p.duration}s ease-in-out infinite`,
              animationDelay: `${p.delay}s`,
            }}
          />
        ))}
      </div>

      <div
        ref={glowRef}
        className="pointer-events-none absolute h-24 w-24 rounded-full bg-[#A855F7] blur-2xl opacity-0"
        style={{ scale: 1 }}
      />

      <div className="relative z-10 flex flex-col items-center gap-6 px-6 text-center">
        <p className="text-3xl sm:text-5xl font-semibold tracking-[0.2em] text-white">
          MUHEEB MALIK
        </p>
        <p className="text-xs sm:text-sm tracking-[0.35em] text-zinc-400">
          DIGITAL GROWTH • CREATIVE • PERFORMANCE
        </p>

        {!ready ? (
          <div className="mt-8 flex flex-col items-center gap-3">
            <p className="text-[11px] tracking-[0.3em] text-zinc-500">
              INITIALIZING EXPERIENCE...
            </p>
            <div className="h-[2px] w-56 overflow-hidden rounded-full bg-white/10">
              <div
                className="h-full bg-gradient-to-r from-[#8B5CF6] via-[#A855F7] to-[#D946EF] transition-[width] duration-150 ease-linear"
                style={{ width: `${progress}%` }}
              />
            </div>
            <span className="text-[11px] tabular-nums text-zinc-500">{progress}%</span>
          </div>
        ) : (
          <button
            onClick={handleEnter}
            className="mt-8 rounded-full border border-[#A855F7]/40 px-8 py-3 text-xs tracking-[0.3em] text-white shadow-[0_0_30px_rgba(168,85,247,0.35)] transition-shadow duration-300 hover:shadow-[0_0_45px_rgba(168,85,247,0.55)]"
          >
            ENTER EXPERIENCE →
          </button>
        )}
      </div>

      <style jsx>{`
        @keyframes floaty {
          0%,
          100% {
            transform: translateY(0px);
          }
          50% {
            transform: translateY(-12px);
          }
        }
      `}</style>
    </div>
  );
}
