"use client";

import { useEffect, useRef } from "react";
import gsap from "gsap";
import { NAV_ITEMS } from "@/lib/constants";
import { scrollToZone } from "@/lib/zones";
import { useReducedMotion } from "@/hooks/useReducedMotion";

interface FullscreenMenuProps {
  open: boolean;
  onClose: () => void;
}

export default function FullscreenMenu({ open, onClose }: FullscreenMenuProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const itemsRef = useRef<HTMLAnchorElement[]>([]);
  const reducedMotion = useReducedMotion();

  useEffect(() => {
    if (!open) return;
    function handleKey(e: KeyboardEvent) {
      if (e.key === "Escape") onClose();
    }
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [open, onClose]);

  useEffect(() => {
    if (!containerRef.current) return;

    if (open) {
      gsap.set(containerRef.current, { display: "flex" });

      if (reducedMotion) {
        gsap.set(containerRef.current, { opacity: 1 });
        gsap.set(itemsRef.current, { opacity: 1, y: 0 });
        return;
      }

      gsap.fromTo(
        containerRef.current,
        { opacity: 0 },
        { opacity: 1, duration: 0.5, ease: "power2.out" }
      );
      gsap.fromTo(
        itemsRef.current,
        { opacity: 0, y: 24 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          ease: "power3.out",
          stagger: 0.06,
          delay: 0.1,
        }
      );
    } else {
      const duration = reducedMotion ? 0.05 : 0.35;
      gsap.to(containerRef.current, {
        opacity: 0,
        duration,
        ease: "power2.in",
        onComplete: () => {
          if (containerRef.current) containerRef.current.style.display = "none";
        },
      });
    }
  }, [open, reducedMotion]);

  return (
    <div
      ref={containerRef}
      role="dialog"
      aria-modal="true"
      aria-label="Site navigation"
      className="fixed inset-0 z-50 hidden flex-col items-center justify-center bg-[#050505]/95 backdrop-blur-xl"
      style={{ opacity: 0 }}
    >
      <div className="pointer-events-none absolute inset-0 overflow-hidden">
        <div className="absolute left-1/2 top-1/2 h-[60vmax] w-[60vmax] -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#8B5CF6]/10 blur-3xl" />
      </div>

      <button
        onClick={onClose}
        className="absolute top-6 right-6 text-xs tracking-[0.3em] text-zinc-400 hover:text-white"
      >
        CLOSE
      </button>

      <nav className="relative z-10 flex flex-col items-center gap-5">
        {NAV_ITEMS.map((item, i) => (
          <a
            key={item.label}
            href={item.href}
            ref={(el) => {
              if (el) itemsRef.current[i] = el;
            }}
            onClick={(e) => {
              if ("zone" in item && item.zone) {
                e.preventDefault();
                scrollToZone(item.zone);
              }
              onClose();
            }}
            className="text-4xl sm:text-6xl font-semibold tracking-wide text-zinc-300 transition-colors duration-300 hover:text-white hover:[text-shadow:0_0_20px_rgba(168,85,247,0.6)]"
          >
            {item.label}
          </a>
        ))}
      </nav>
    </div>
  );
}
