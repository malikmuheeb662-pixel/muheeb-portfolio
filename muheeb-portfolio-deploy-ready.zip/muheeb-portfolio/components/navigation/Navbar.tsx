"use client";

import { scrollToZone } from "@/lib/zones";

interface NavbarProps {
  onMenuClick: () => void;
  visible: boolean;
}

export default function Navbar({ onMenuClick, visible }: NavbarProps) {
  return (
    <header
      className={`fixed top-0 left-0 right-0 z-40 flex justify-center px-4 pt-4 transition-opacity duration-700 ${
        visible ? "opacity-100" : "opacity-0 pointer-events-none"
      }`}
    >
      <nav className="flex w-full max-w-5xl items-center justify-between rounded-full border border-white/[0.08] bg-white/[0.03] px-6 py-3 backdrop-blur-md">
        <span className="text-sm tracking-[0.25em] text-white">MUHEEB MALIK</span>
        <div className="flex items-center gap-6">
          <button
            onClick={onMenuClick}
            className="text-xs tracking-[0.25em] text-zinc-300 transition-colors hover:text-white"
          >
            MENU
          </button>
          <button
            onClick={() => scrollToZone("contact")}
            className="text-xs tracking-[0.25em] text-zinc-300 transition-colors hover:text-white"
          >
            CONTACT
          </button>
        </div>
      </nav>
    </header>
  );
}
