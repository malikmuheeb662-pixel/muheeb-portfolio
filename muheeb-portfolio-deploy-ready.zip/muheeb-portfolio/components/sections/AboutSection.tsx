"use client";

import SectionLabel from "@/components/ui/SectionLabel";
import GlassPanel from "@/components/ui/GlassPanel";

interface TimelineStep {
  label: string;
  detail: string;
}

const TIMELINE: TimelineStep[] = [
  { label: "B.COM", detail: "School of Open Learning, University of Delhi" },
  { label: "MBA", detail: "IGNOU" },
  { label: "15 MAY 2026", detail: "Started Digital Marketing learning journey" },
  { label: "DIDM", detail: "Digital Marketing learning + practical exposure" },
  { label: "REAL PROJECTS", detail: "Mubix Digital, DIDM Kalkaji, Krypt" },
  { label: "CURRENT FOCUS", detail: "Performance Marketing" },
];

interface AboutSectionProps {
  localProgress?: number; // 0-1 position within the About zone, drives the timeline highlight
}

export default function AboutSection({ localProgress = 0 }: AboutSectionProps) {
  const activeIndex = Math.min(TIMELINE.length - 1, Math.floor(localProgress * TIMELINE.length));

  return (
    <div id="about" className="relative flex h-full w-full items-center justify-center px-6">
      <div className="mx-auto grid w-full max-w-5xl gap-10 md:grid-cols-2 md:items-center">
        <div className="flex flex-col gap-5">
          <SectionLabel>About</SectionLabel>
          <h2 className="text-3xl font-semibold leading-tight text-white sm:text-4xl lg:text-5xl">
            WHO IS MUHEEB?
          </h2>
          <p className="text-sm tracking-[0.25em] text-zinc-400">
            DIGITAL GROWTH &amp; CREATIVE PROFESSIONAL
          </p>
          <p className="max-w-md text-sm leading-relaxed text-zinc-400 sm:text-base">
            Muheeb is a digital professional with hands-on experience across web
            development, SEO, e-commerce, creative production and paid traffic
            campaigns — while currently building deeper expertise in Performance
            Marketing.
          </p>
        </div>

        <ol className="flex flex-col gap-3">
          {TIMELINE.map((step, i) => {
            const distance = Math.abs(i - activeIndex);
            const emphasis = Math.max(0, 1 - distance * 0.35);
            return (
              <li key={step.label}>
                <GlassPanel
                  className="px-5 py-3 transition-[opacity,transform] duration-300 ease-out"
                >
                  <div
                    style={{
                      opacity: 0.45 + emphasis * 0.55,
                      transform: `scale(${0.95 + emphasis * 0.05})`,
                    }}
                  >
                    <p className="text-xs tracking-[0.25em] text-[#D946EF]">{step.label}</p>
                    <p className="mt-1 text-sm text-zinc-300">{step.detail}</p>
                  </div>
                </GlassPanel>
              </li>
            );
          })}
        </ol>
      </div>
    </div>
  );
}
