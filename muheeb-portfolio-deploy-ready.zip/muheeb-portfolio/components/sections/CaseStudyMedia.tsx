import type { CaseStudyMediaSpec } from "@/lib/caseStudies";

interface CaseStudyImageProps {
  src?: string;
  alt?: string;
  label?: string;
  className?: string;
}

/**
 * Reusable case-study media placeholders. Pass `src` once a real asset
 * exists — the rest of the case study doesn't need to change. Never
 * fabricates screenshots; the placeholder always says so plainly.
 */
export function CaseStudyImage({
  src,
  alt,
  label = "ADD PROJECT SCREENSHOT",
  className = "",
}: CaseStudyImageProps) {
  if (src) {
    return (
      // eslint-disable-next-line @next/next/no-img-element -- placeholder architecture; swap to next/image once real assets are supplied
      <img src={src} alt={alt ?? ""} className={`w-full rounded-xl object-cover ${className}`} />
    );
  }

  return (
    <div
      className={`flex min-h-[160px] w-full flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-white/15 bg-white/[0.02] ${className}`}
    >
      <span className="text-[10px] tracking-[0.3em] text-zinc-500">{label}</span>
      <span className="h-px w-10 bg-gradient-to-r from-transparent via-[#A855F7]/50 to-transparent" />
    </div>
  );
}

interface CaseStudyVideoProps {
  src?: string;
  label?: string;
  className?: string;
}

export function CaseStudyVideo({
  src,
  label = "PROJECT MEDIA",
  className = "",
}: CaseStudyVideoProps) {
  if (src) {
    return <video src={src} controls className={`w-full rounded-xl ${className}`} />;
  }

  return (
    <div
      className={`flex min-h-[160px] w-full flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-white/15 bg-white/[0.02] ${className}`}
    >
      <span className="text-[10px] tracking-[0.3em] text-zinc-500">{label}</span>
      <span className="text-xs text-zinc-600">Video placeholder</span>
    </div>
  );
}

interface CaseStudyGalleryProps {
  items?: { src: string; alt?: string }[];
  label?: string;
  count?: number;
  className?: string;
}

export function CaseStudyGallery({
  items,
  label = "ADD PROJECT SCREENSHOT",
  count = 3,
  className = "",
}: CaseStudyGalleryProps) {
  const slots = items && items.length > 0 ? items : Array.from({ length: count }, () => null);

  return (
    <div className={`grid grid-cols-2 gap-3 sm:grid-cols-3 ${className}`}>
      {slots.map((item, i) =>
        item ? (
          <CaseStudyImage key={i} src={item.src} alt={item.alt} />
        ) : (
          <CaseStudyImage key={i} label={label} />
        )
      )}
    </div>
  );
}

/**
 * Renders the right placeholder type for a data-driven media spec, so
 * <CaseStudyOverlay /> can stay purely data-driven instead of branching
 * per project.
 */
export function CaseStudyMedia({ spec }: { spec: CaseStudyMediaSpec }) {
  if (spec.kind === "video") return <CaseStudyVideo label={spec.label} />;
  if (spec.kind === "gallery") return <CaseStudyGallery label={spec.label} count={spec.count ?? 3} />;
  return <CaseStudyImage label={spec.label} />;
}
