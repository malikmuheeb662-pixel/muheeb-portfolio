"use client";

import { useEffect, useRef } from "react";
import GlassPanel from "@/components/ui/GlassPanel";
import SectionLabel from "@/components/ui/SectionLabel";
import CaseStudySectionNav from "./CaseStudySectionNav";
import { CaseStudyMedia } from "./CaseStudyMedia";
import StaticFallbackBackground from "@/components/three/StaticFallbackBackground";
import { CASE_STUDIES, getNextProjectId, type ProjectId } from "@/lib/caseStudies";
import { useElementScrollProgress } from "@/hooks/useElementScrollProgress";
import type { MutableRefObject } from "react";

interface CaseStudyOverlayProps {
  projectId: ProjectId;
  onClose: () => void;
  onOpenProject: (id: ProjectId) => void;
  webglSupported: boolean | null;
  reducedMotion: boolean;
  progressRef: MutableRefObject<number>;
}

/**
 * One reusable overlay renders all three case studies from data
 * (`lib/caseStudies.ts`) — no per-project page implementations. It sits
 * above the shared Canvas (which switches to that project's abstract
 * environment behind it) as a fixed, scrollable layer with its own
 * independent scroll, so opening/closing never disturbs the visitor's
 * position in the Hero/About/Skills/Work journey underneath.
 */
export default function CaseStudyOverlay({
  projectId,
  onClose,
  onOpenProject,
  webglSupported,
  reducedMotion,
  progressRef,
}: CaseStudyOverlayProps) {
  const data = CASE_STUDIES[projectId];
  const containerRef = useRef<HTMLDivElement>(null);
  const closeButtonRef = useRef<HTMLButtonElement>(null);
  const localProgress = useElementScrollProgress(containerRef);

  useEffect(() => {
    progressRef.current = localProgress;
  }, [localProgress, progressRef]);

  // Freeze the background page scroll while the case study is open, and
  // restore it exactly on close — this is what makes "restore the Work zone
  // correctly" work without any extra bookkeeping.
  useEffect(() => {
    const original = document.body.style.overflow;
    document.body.style.overflow = "hidden";
    return () => {
      document.body.style.overflow = original;
    };
  }, []);

  useEffect(() => {
    closeButtonRef.current?.focus();
  }, [projectId]);

  useEffect(() => {
    function handleKey(e: KeyboardEvent) {
      if (e.key === "Escape") onClose();
    }
    window.addEventListener("keydown", handleKey);
    return () => window.removeEventListener("keydown", handleKey);
  }, [onClose]);

  const navItems = [
    { id: "overview", label: "OVERVIEW" },
    ...data.sections.map((s) => ({ id: s.id, label: s.label })),
    { id: "learned", label: "WHAT I LEARNED" },
  ];

  function scrollToSection(id: string) {
    const el = containerRef.current?.querySelector<HTMLElement>(`#${CSS.escape(id)}`);
    el?.scrollIntoView({ behavior: reducedMotion ? "auto" : "smooth", block: "start" });
  }

  const nextId = getNextProjectId(projectId);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label={`${data.title} case study`}
      className="fixed inset-0 z-[60]"
    >
      {/* Only rendered when there's no shared Canvas to show an environment
          behind this overlay; otherwise the Canvas shows through directly. */}
      {webglSupported === false && <StaticFallbackBackground />}

      <button
        ref={closeButtonRef}
        type="button"
        onClick={onClose}
        className="absolute left-4 top-4 z-10 flex items-center gap-2 rounded-full border border-white/15 bg-black/40 px-4 py-2 text-xs tracking-[0.2em] text-zinc-200 backdrop-blur-md transition-colors hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#A855F7] sm:left-8 sm:top-8"
      >
        ← BACK TO WORK
      </button>

      <div className="absolute right-4 top-24 z-10 hidden max-w-[160px] sm:right-8 sm:block">
        <CaseStudySectionNav items={navItems} containerRef={containerRef} onSelect={scrollToSection} />
      </div>

      <div
        ref={containerRef}
        className="h-full w-full overflow-y-auto px-6 py-24 sm:px-10"
      >
        <div className="mx-auto flex max-w-3xl flex-col gap-20 pb-24">
          {/* HERO + OVERVIEW + ROLE */}
          <section id="overview" className="flex flex-col gap-4">
            <SectionLabel>{`0${data.order} / Case Study`}</SectionLabel>
            <h2 className="text-4xl font-semibold text-white sm:text-5xl lg:text-6xl">
              {data.title}
            </h2>
            <p className="text-xs tracking-[0.25em] text-[#D946EF]">{data.category}</p>
            <p className="max-w-xl text-base text-zinc-300">{data.positioning}</p>

            <GlassPanel className="mt-4 max-w-xl px-6 py-5">
              <p className="text-xs tracking-[0.25em] text-zinc-400">MY ROLE</p>
              <p className="mt-2 text-sm leading-relaxed text-zinc-300">{data.myRole}</p>
            </GlassPanel>

            <div className="mt-6 max-w-xl">
              <h2 className="text-xl font-semibold text-white sm:text-2xl">
                {data.overviewHeading}
              </h2>
              <p className="mt-3 text-sm leading-relaxed text-zinc-400">{data.overview}</p>
            </div>
          </section>

          {data.sections.map((section) => (
            <section key={section.id} id={section.id} className="flex flex-col gap-5">
              <h2 className="text-2xl font-semibold text-white sm:text-3xl">
                {section.heading}
              </h2>
              <p className="max-w-xl text-sm leading-relaxed text-zinc-400">{section.body}</p>
              <div className="flex flex-col gap-4 sm:flex-row sm:flex-wrap">
                {section.media.map((m, i) => (
                  <div key={i} className="w-full sm:max-w-md">
                    <CaseStudyMedia spec={m} />
                  </div>
                ))}
              </div>
            </section>
          ))}

          <section id="learned" className="flex flex-col gap-4">
            <h2 className="text-2xl font-semibold text-white sm:text-3xl">WHAT I LEARNED</h2>
            <ul className="flex flex-col gap-2">
              {data.whatILearned.map((point) => (
                <li key={point} className="flex items-start gap-2 text-sm text-zinc-400">
                  <span className="mt-1.5 h-1 w-1 flex-none rounded-full bg-[#A855F7]" />
                  {point}
                </li>
              ))}
            </ul>
          </section>

          <section className="flex flex-col items-center gap-4 border-t border-white/10 pt-12 text-center">
            <button
              type="button"
              onClick={() => onOpenProject(nextId)}
              className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-[#8B5CF6] via-[#A855F7] to-[#D946EF] px-7 py-3 text-sm tracking-widest text-white shadow-[0_0_24px_rgba(168,85,247,0.35)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
            >
              NEXT PROJECT: {CASE_STUDIES[nextId].title} →
            </button>
            <button
              type="button"
              onClick={onClose}
              className="rounded text-xs tracking-[0.25em] text-zinc-400 underline-offset-4 hover:text-white hover:underline focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#A855F7]"
            >
              ← BACK TO WORK
            </button>
          </section>
        </div>
      </div>
    </div>
  );
}
