"use client";

import { RefObject, useEffect, useState } from "react";

interface NavItem {
  id: string;
  label: string;
}

interface CaseStudySectionNavProps {
  items: NavItem[];
  containerRef: RefObject<HTMLElement | null>;
  onSelect: (id: string) => void;
}

/**
 * Subtle, scroll-synced progress indicator for a case study. Watches which
 * section is current inside the case study's own scroll container (not the
 * window) via IntersectionObserver, and doubles as keyboard-accessible
 * jump-to-section navigation.
 */
export default function CaseStudySectionNav({
  items,
  containerRef,
  onSelect,
}: CaseStudySectionNavProps) {
  const [activeId, setActiveId] = useState(items[0]?.id);

  useEffect(() => {
    const root = containerRef.current;
    if (!root) return;

    const elements = items
      .map((item) => root.querySelector<HTMLElement>(`#${CSS.escape(item.id)}`))
      .filter((el): el is HTMLElement => el !== null);

    if (elements.length === 0) return;

    const observer = new IntersectionObserver(
      (entries) => {
        const visible = entries.filter((entry) => entry.isIntersecting);
        if (visible.length === 0) return;
        const topMost = visible.reduce((a, b) =>
          a.boundingClientRect.top < b.boundingClientRect.top ? a : b
        );
        setActiveId(topMost.target.id);
      },
      { root, threshold: 0.3 }
    );

    elements.forEach((el) => observer.observe(el));
    return () => observer.disconnect();
  }, [items, containerRef]);

  return (
    <nav aria-label="Case study sections" className="flex flex-col items-end gap-3">
      {items.map((item) => (
        <button
          key={item.id}
          type="button"
          aria-current={activeId === item.id ? "true" : undefined}
          onClick={() => onSelect(item.id)}
          className={`rounded text-right text-[10px] tracking-[0.2em] transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#A855F7] ${
            activeId === item.id ? "text-white" : "text-zinc-500 hover:text-zinc-300"
          }`}
        >
          {item.label}
        </button>
      ))}
    </nav>
  );
}
