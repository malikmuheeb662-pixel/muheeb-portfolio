import GlassPanel from "@/components/ui/GlassPanel";
import type { CertificationData } from "@/lib/certifications";

export default function CertificationCard({ certification }: { certification: CertificationData }) {
  const isComingSoon = certification.status === "coming-soon";

  return (
    <GlassPanel className="flex h-full flex-col gap-4 p-5 transition-all duration-300 hover:-translate-y-1 hover:border-[#A855F7]/40 hover:shadow-[0_0_30px_rgba(168,85,247,0.2)] focus-within:-translate-y-1 focus-within:border-[#A855F7]/40 focus-within:shadow-[0_0_30px_rgba(168,85,247,0.2)]">
      {certification.imageSrc ? (
        // eslint-disable-next-line @next/next/no-img-element -- placeholder architecture; swap to next/image once a real certificate image is supplied
        <img
          src={certification.imageSrc}
          alt={`${certification.title} certificate`}
          className="h-40 w-full rounded-xl object-cover"
        />
      ) : (
        <div className="flex h-40 w-full flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-white/15 bg-white/[0.02]">
          <span className="text-[10px] tracking-[0.3em] text-zinc-500">
            {isComingSoon ? "CERTIFICATION — COMING SOON" : "CERTIFICATE PREVIEW"}
          </span>
          <span className="h-px w-10 bg-gradient-to-r from-transparent via-[#A855F7]/50 to-transparent" />
        </div>
      )}

      <div className="flex flex-1 flex-col gap-1">
        <h3 className="text-lg font-semibold text-white">{certification.title}</h3>
        <p className="text-sm text-zinc-400">
          {certification.issuer ? `Issued by ${certification.issuer}` : "Issuer to be confirmed"}
        </p>
        {certification.note && (
          <p className="mt-1 text-xs text-zinc-500">{certification.note}</p>
        )}
      </div>

      {certification.credentialUrl && (
        <a
          href={certification.credentialUrl}
          target="_blank"
          rel="noreferrer"
          className="inline-flex w-fit items-center gap-2 rounded-full border border-[#A855F7]/40 px-4 py-2 text-xs tracking-widest text-white transition-shadow duration-300 hover:shadow-[0_0_18px_rgba(168,85,247,0.3)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#A855F7]"
        >
          VIEW CERTIFICATE →
        </a>
      )}
    </GlassPanel>
  );
}
