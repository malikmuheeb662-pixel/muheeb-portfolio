import SectionLabel from "@/components/ui/SectionLabel";
import CertificationCard from "./CertificationCard";
import { CERTIFICATIONS } from "@/lib/certifications";

export default function CertificationGrid() {
  return (
    <div
      id="certifications"
      className="relative flex h-full w-full items-center justify-center overflow-y-auto px-6 py-16"
    >
      <div className="mx-auto flex w-full max-w-4xl flex-col gap-8">
        <div className="flex flex-col items-center gap-3 text-center">
          <SectionLabel>Certifications</SectionLabel>
          <h2 className="text-3xl font-semibold text-white sm:text-4xl lg:text-5xl">
            CERTIFICATIONS
          </h2>
          <p className="max-w-lg text-sm text-zinc-400 sm:text-base">
            Credentials that support my learning across digital marketing, search and AI.
          </p>
        </div>

        <ul className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {CERTIFICATIONS.map((cert) => (
            <li key={cert.id}>
              <CertificationCard certification={cert} />
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
