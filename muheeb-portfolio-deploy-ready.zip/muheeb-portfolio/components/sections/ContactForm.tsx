"use client";

import { useState, type FormEvent } from "react";
import GlassPanel from "@/components/ui/GlassPanel";

type FormStatus = "idle" | "invalid" | "submitted";

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

/**
 * There is currently no backend/email service configured for this form.
 * On submit it never claims a message was sent — it clearly communicates
 * that the backend still needs to be connected. Wire a real endpoint into
 * handleSubmit() below once one exists; nothing else needs to change.
 */
export default function ContactForm() {
  const [status, setStatus] = useState<FormStatus>("idle");
  const [errors, setErrors] = useState<{ name?: string; email?: string; message?: string }>({});

  function handleSubmit(e: FormEvent<HTMLFormElement>) {
    e.preventDefault();
    const form = e.currentTarget;
    const name = (form.elements.namedItem("name") as HTMLInputElement).value.trim();
    const email = (form.elements.namedItem("email") as HTMLInputElement).value.trim();
    const message = (form.elements.namedItem("message") as HTMLTextAreaElement).value.trim();

    const nextErrors: typeof errors = {};
    if (!name) nextErrors.name = "Please enter your name.";
    if (!email) nextErrors.email = "Please enter your email.";
    else if (!EMAIL_PATTERN.test(email)) nextErrors.email = "Please enter a valid email address.";
    if (!message) nextErrors.message = "Please add a short message.";

    setErrors(nextErrors);

    if (Object.keys(nextErrors).length > 0) {
      setStatus("invalid");
      return;
    }

    // No backend/email service is configured yet — never claim success.
    setStatus("submitted");
  }

  return (
    <GlassPanel className="p-6 sm:p-8">
      <form onSubmit={handleSubmit} noValidate className="flex flex-col gap-5">
        <div className="flex flex-col gap-2">
          <label htmlFor="contact-name" className="text-xs tracking-[0.25em] text-zinc-400">
            NAME
          </label>
          <input
            id="contact-name"
            name="name"
            type="text"
            placeholder="Your name"
            required
            aria-required="true"
            aria-invalid={Boolean(errors.name)}
            aria-describedby={errors.name ? "contact-name-error" : undefined}
            className="rounded-lg border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-white placeholder:text-zinc-600 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#A855F7]"
          />
          {errors.name && (
            <p id="contact-name-error" className="text-xs text-[#D946EF]">
              {errors.name}
            </p>
          )}
        </div>

        <div className="flex flex-col gap-2">
          <label htmlFor="contact-email" className="text-xs tracking-[0.25em] text-zinc-400">
            EMAIL
          </label>
          <input
            id="contact-email"
            name="email"
            type="email"
            placeholder="you@example.com"
            required
            aria-required="true"
            aria-invalid={Boolean(errors.email)}
            aria-describedby={errors.email ? "contact-email-error" : undefined}
            className="rounded-lg border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-white placeholder:text-zinc-600 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#A855F7]"
          />
          {errors.email && (
            <p id="contact-email-error" className="text-xs text-[#D946EF]">
              {errors.email}
            </p>
          )}
        </div>

        <div className="flex flex-col gap-2">
          <label htmlFor="contact-message" className="text-xs tracking-[0.25em] text-zinc-400">
            MESSAGE
          </label>
          <textarea
            id="contact-message"
            name="message"
            rows={5}
            placeholder="Tell me a little about your project or opportunity..."
            required
            aria-required="true"
            aria-invalid={Boolean(errors.message)}
            aria-describedby={errors.message ? "contact-message-error" : undefined}
            className="resize-none rounded-lg border border-white/10 bg-white/[0.03] px-4 py-3 text-sm text-white placeholder:text-zinc-600 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#A855F7]"
          />
          {errors.message && (
            <p id="contact-message-error" className="text-xs text-[#D946EF]">
              {errors.message}
            </p>
          )}
        </div>

        <button
          type="submit"
          className="inline-flex w-fit items-center gap-2 rounded-full bg-gradient-to-r from-[#8B5CF6] via-[#A855F7] to-[#D946EF] px-7 py-3 text-sm tracking-widest text-white shadow-[0_0_24px_rgba(168,85,247,0.35)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
        >
          SEND MESSAGE →
        </button>

        <p role="status" aria-live="polite" className="text-xs text-zinc-500">
          {status === "submitted" &&
            "FORM SUBMISSION NOT CONFIGURED YET — this form isn't connected to a backend yet, so your message wasn't sent. Please use one of the contact channels instead for now."}
          {status === "invalid" && "Please fix the highlighted fields and try again."}
        </p>
      </form>
    </GlassPanel>
  );
}
