import { Mail, Briefcase, MessageCircle, Camera, type LucideIcon } from "lucide-react";
import { getContactHref, type ContactChannel } from "@/lib/contact";

const ICONS: Record<ContactChannel["id"], LucideIcon> = {
  email: Mail,
  linkedin: Briefcase,
  whatsapp: MessageCircle,
  instagram: Camera,
};

export default function ContactLink({ channel }: { channel: ContactChannel }) {
  const href = getContactHref(channel);
  const Icon = ICONS[channel.id];

  const content = (
    <>
      <Icon className="h-5 w-5 text-[#A855F7]" aria-hidden="true" />
      <div className="flex flex-col">
        <span className="text-xs tracking-[0.25em] text-white">{channel.label}</span>
        <span className="text-xs text-zinc-500">
          {href ? channel.description : "Link coming soon"}
        </span>
      </div>
    </>
  );

  const baseClasses =
    "flex items-center gap-3 rounded-2xl border px-4 py-3 transition-all duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#A855F7]";

  if (href) {
    return (
      <a
        href={href}
        target={channel.id === "email" ? undefined : "_blank"}
        rel={channel.id === "email" ? undefined : "noreferrer"}
        aria-label={`${channel.label.charAt(0)}${channel.label.slice(1).toLowerCase()} — ${channel.description}`}
        className={`${baseClasses} border-white/[0.08] bg-white/[0.03] hover:border-[#A855F7]/40 hover:shadow-[0_0_24px_rgba(168,85,247,0.2)]`}
      >
        {content}
      </a>
    );
  }

  return (
    <span
      aria-disabled="true"
      title={`${channel.label} link coming soon`}
      className={`${baseClasses} cursor-not-allowed border-white/[0.05] bg-white/[0.01] opacity-60`}
    >
      {content}
    </span>
  );
}
