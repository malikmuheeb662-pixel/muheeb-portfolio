import ContactLink from "./ContactLink";
import { CONTACT_CHANNELS } from "@/lib/contact";

interface ContactLinksProps {
  className?: string;
  /** Column count at the sm breakpoint and up. Passed explicitly rather than
   *  via a className override, since two conflicting `sm:grid-cols-*`
   *  utility classes on the same element have an unpredictable winner
   *  (Tailwind resolves by stylesheet generation order, not DOM order). */
  columns?: 2 | 4;
}

const COLUMN_CLASSES: Record<NonNullable<ContactLinksProps["columns"]>, string> = {
  2: "sm:grid-cols-2",
  4: "sm:grid-cols-2 lg:grid-cols-4",
};

export default function ContactLinks({ className = "", columns = 2 }: ContactLinksProps) {
  return (
    <ul className={`grid grid-cols-1 gap-3 ${COLUMN_CLASSES[columns]} ${className}`}>
      {CONTACT_CHANNELS.map((channel) => (
        <li key={channel.id}>
          <ContactLink channel={channel} />
        </li>
      ))}
    </ul>
  );
}
