import SectionLabel from "@/components/ui/SectionLabel";
import ContactForm from "./ContactForm";
import ContactLinks from "./ContactLinks";

export default function ContactSection() {
  return (
    <div id="contact" className="relative flex h-full w-full items-center justify-center overflow-y-auto px-6 py-16">
      <div className="mx-auto grid w-full max-w-5xl gap-10 md:grid-cols-2 md:items-start">
        <div className="flex flex-col gap-5">
          <SectionLabel>Contact</SectionLabel>
          <h2 className="text-3xl font-semibold leading-tight text-white sm:text-4xl lg:text-5xl">
            LET&apos;S CONNECT
          </h2>
          <p className="max-w-md text-sm leading-relaxed text-zinc-400 sm:text-base">
            Have a project, opportunity or idea in mind? I&apos;d love to hear from you.
          </p>

          <div className="mt-4">
            <ContactLinks />
          </div>
        </div>

        <ContactForm />
      </div>
    </div>
  );
}
