import MagneticButton from "@/components/ui/MagneticButton";
import Footer from "./Footer";
import { scrollToZone } from "@/lib/zones";

export default function FinalCTA() {
  return (
    <div
      id="final"
      className="relative flex h-full w-full flex-col items-center justify-between overflow-y-auto px-6 py-16"
    >
      <div className="flex flex-1 flex-col items-center justify-center gap-6 text-center">
        <h2 className="max-w-3xl text-4xl font-semibold leading-tight text-white sm:text-5xl lg:text-6xl">
          LET&apos;S BUILD SOMETHING GREAT.
        </h2>
        <p className="max-w-xl text-sm leading-relaxed text-zinc-400 sm:text-base">
          Digital experiences, creative ideas and growth-focused thinking — let&apos;s turn them
          into something meaningful.
        </p>

        <div className="mt-4 flex flex-wrap items-center justify-center gap-4">
          <MagneticButton
            href="#contact"
            variant="primary"
            onClick={() => scrollToZone("contact")}
          >
            START A CONVERSATION →
          </MagneticButton>
          <MagneticButton href="#work" variant="secondary" onClick={() => scrollToZone("work")}>
            VIEW MY WORK →
          </MagneticButton>
        </div>
      </div>

      <div className="mt-16 w-full">
        <Footer />
      </div>
    </div>
  );
}
