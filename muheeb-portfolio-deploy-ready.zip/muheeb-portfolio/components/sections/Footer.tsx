"use client";

import ContactLinks from "./ContactLinks";
import { NAV_ITEMS } from "@/lib/constants";
import { scrollToZone, type ZoneName } from "@/lib/zones";

export default function Footer() {
  return (
    <footer className="flex w-full flex-col items-center gap-6 border-t border-white/10 pt-8 text-center">
      <div>
        <p className="text-lg font-semibold tracking-wide text-white">MUHEEB MALIK</p>
        <p className="text-xs tracking-[0.25em] text-zinc-500">
          DIGITAL GROWTH &amp; CREATIVE PROFESSIONAL
        </p>
      </div>

      <nav aria-label="Footer navigation" className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2">
        {NAV_ITEMS.map((item) => (
          <button
            key={item.label}
            type="button"
            onClick={() => {
              if ("zone" in item && item.zone) {
                scrollToZone(item.zone as ZoneName);
              }
            }}
            className="text-xs tracking-[0.2em] text-zinc-400 transition-colors hover:text-white focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#A855F7] rounded"
          >
            {item.label}
          </button>
        ))}
      </nav>

      <ContactLinks className="max-w-md" columns={4} />

      <p className="text-xs text-zinc-600">© 2026 Muheeb Malik</p>
    </footer>
  );
}
