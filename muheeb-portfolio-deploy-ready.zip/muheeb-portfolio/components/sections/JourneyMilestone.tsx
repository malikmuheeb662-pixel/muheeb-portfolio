"use client";

import GlassPanel from "@/components/ui/GlassPanel";
import { useExperience } from "@/components/experience/ExperienceContext";
import type { JourneyMilestoneData } from "@/lib/journey";

interface JourneyMilestoneProps {
  milestone: JourneyMilestoneData;
  emphasis: number; // 0-1, driven by scroll position within the Journey zone
}

export default function JourneyMilestone({ milestone, emphasis }: JourneyMilestoneProps) {
  const { hoveredMilestone, setHoveredMilestone } = useExperience();
  const isHovered = hoveredMilestone === milestone.id;
  const combinedEmphasis = Math.max(emphasis, isHovered ? 1 : 0);

  return (
    <GlassPanel
      className={`transition-[border-color,box-shadow] duration-300 ${
        isHovered ? "border-[#A855F7]/50 shadow-[0_0_28px_rgba(168,85,247,0.25)]" : ""
      }`}
    >
      <button
        type="button"
        onMouseEnter={() => setHoveredMilestone(milestone.id)}
        onMouseLeave={() => setHoveredMilestone(null)}
        onFocus={() => setHoveredMilestone(milestone.id)}
        onBlur={() => setHoveredMilestone(null)}
        onTouchStart={() => setHoveredMilestone(milestone.id)}
        aria-label={`${milestone.title}${milestone.subtitle ? ` — ${milestone.subtitle}` : ""}`}
        className="w-full px-5 py-4 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#A855F7]"
      >
        <div
          style={{
            opacity: 0.45 + combinedEmphasis * 0.55,
            transform: `scale(${0.95 + combinedEmphasis * 0.05})`,
          }}
        >
          <p className="text-xs tracking-[0.25em] text-[#D946EF]">{milestone.label}</p>
          <p className="mt-1 text-base font-medium text-white">{milestone.title}</p>
          <p className="mt-1 text-sm text-zinc-400">{milestone.subtitle}</p>
        </div>
      </button>
    </GlassPanel>
  );
}
