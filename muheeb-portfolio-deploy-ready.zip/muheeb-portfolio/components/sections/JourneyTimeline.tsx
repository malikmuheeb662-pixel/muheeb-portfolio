"use client";

import SectionLabel from "@/components/ui/SectionLabel";
import JourneyMilestone from "./JourneyMilestone";
import { JOURNEY_MILESTONES } from "@/lib/journey";

interface JourneyTimelineProps {
  localProgress?: number;
}

export default function JourneyTimeline({ localProgress = 0 }: JourneyTimelineProps) {
  const activeIndex = Math.min(
    JOURNEY_MILESTONES.length - 1,
    Math.floor(localProgress * JOURNEY_MILESTONES.length)
  );

  return (
    <div id="journey" className="relative flex h-full w-full items-center justify-center overflow-y-auto px-6 py-16">
      <div className="mx-auto flex w-full max-w-2xl flex-col gap-8">
        <div className="flex flex-col items-center gap-3 text-center">
          <SectionLabel>Journey</SectionLabel>
          <h2 className="text-3xl font-semibold text-white sm:text-4xl lg:text-5xl">
            MY JOURNEY
          </h2>
          <p className="max-w-lg text-sm text-zinc-400 sm:text-base">
            From learning the fundamentals to building real digital projects and developing
            deeper expertise in Performance Marketing.
          </p>
        </div>

        <ol className="flex flex-col gap-3">
          {JOURNEY_MILESTONES.map((milestone, i) => {
            const distance = Math.abs(i - activeIndex);
            const emphasis = Math.max(0, 1 - distance * 0.35);
            return (
              <li key={milestone.id}>
                <JourneyMilestone milestone={milestone} emphasis={emphasis} />
              </li>
            );
          })}
        </ol>
      </div>
    </div>
  );
}
