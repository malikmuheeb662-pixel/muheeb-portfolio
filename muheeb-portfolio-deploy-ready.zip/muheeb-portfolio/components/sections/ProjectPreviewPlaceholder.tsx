interface ProjectPreviewPlaceholderProps {
  imageSrc?: string;
  imageAlt?: string;
}

/**
 * Structured placeholder standing in for real project media (website
 * screenshots, ad creatives, SEO/Shopify screenshots, videos). Pass
 * `imageSrc` once real assets exist — the rest of <WorkSection /> doesn't
 * need to change.
 */
export default function ProjectPreviewPlaceholder({
  imageSrc,
  imageAlt,
}: ProjectPreviewPlaceholderProps) {
  if (imageSrc) {
    return (
      // eslint-disable-next-line @next/next/no-img-element -- placeholder architecture; swap to next/image once real assets are supplied
      <img
        src={imageSrc}
        alt={imageAlt ?? ""}
        className="h-full w-full rounded-xl object-cover"
      />
    );
  }

  return (
    <div className="flex h-full min-h-[160px] w-full flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-white/15 bg-white/[0.02]">
      <span className="text-[10px] tracking-[0.3em] text-zinc-500">PROJECT PREVIEW</span>
      <span className="h-px w-10 bg-gradient-to-r from-transparent via-[#A855F7]/50 to-transparent" />
    </div>
  );
}
