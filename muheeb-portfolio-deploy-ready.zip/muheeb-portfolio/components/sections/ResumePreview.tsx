import GlassPanel from "@/components/ui/GlassPanel";

export default function ResumePreview() {
  return (
    <GlassPanel className="flex flex-col items-center gap-3 px-8 py-10 text-center">
      <p className="text-2xl font-semibold tracking-wide text-white sm:text-3xl">
        MUHEEB MALIK
      </p>
      <p className="text-xs tracking-[0.3em] text-zinc-400">
        DIGITAL GROWTH &amp; CREATIVE PROFESSIONAL
      </p>
      <p className="mt-2 text-xs tracking-[0.2em] text-[#D946EF]">
        WEB • SEO • PERFORMANCE MARKETING • CREATIVE • E-COMMERCE
      </p>
    </GlassPanel>
  );
}
