import SectionLabel from "@/components/ui/SectionLabel";
import GlassPanel from "@/components/ui/GlassPanel";
import ResumePreview from "./ResumePreview";
import {
  RESUME_EDUCATION,
  RESUME_LEARNING,
  RESUME_CAPABILITIES,
  RESUME_PROJECTS,
  RESUME_FILE_URL,
} from "@/lib/resume";

export default function ResumeSection() {
  return (
    <div id="resume" className="relative flex h-full w-full items-center justify-center overflow-y-auto px-6 py-16">
      <div className="mx-auto flex w-full max-w-3xl flex-col gap-8">
        <div className="flex flex-col items-center gap-3 text-center">
          <SectionLabel>Resume</SectionLabel>
          <h2 className="text-3xl font-semibold text-white sm:text-4xl lg:text-5xl">RESUME</h2>
          <p className="max-w-lg text-sm text-zinc-400 sm:text-base">
            A concise overview of my education, skills, projects and digital marketing journey.
          </p>
        </div>

        <ResumePreview />

        <div className="grid gap-6 sm:grid-cols-2">
          <GlassPanel className="p-6">
            <h3 className="text-xs tracking-[0.25em] text-[#D946EF]">EDUCATION</h3>
            <ul className="mt-3 flex flex-col gap-3">
              {RESUME_EDUCATION.map((item) => (
                <li key={item.title}>
                  <p className="text-sm font-medium text-white">{item.title}</p>
                  <p className="text-sm text-zinc-400">{item.detail}</p>
                </li>
              ))}
            </ul>
          </GlassPanel>

          <GlassPanel className="p-6">
            <h3 className="text-xs tracking-[0.25em] text-[#D946EF]">DIGITAL MARKETING LEARNING</h3>
            <div className="mt-3">
              <p className="text-sm font-medium text-white">{RESUME_LEARNING.title}</p>
              <p className="text-sm text-zinc-400">{RESUME_LEARNING.detail}</p>
            </div>
          </GlassPanel>

          <GlassPanel className="p-6 sm:col-span-2">
            <h3 className="text-xs tracking-[0.25em] text-[#D946EF]">CORE CAPABILITIES</h3>
            <ul className="mt-3 flex flex-wrap gap-2">
              {RESUME_CAPABILITIES.map((skill) => (
                <li
                  key={skill}
                  className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1 text-xs tracking-wide text-zinc-300"
                >
                  {skill}
                </li>
              ))}
            </ul>
          </GlassPanel>

          <GlassPanel className="p-6 sm:col-span-2">
            <h3 className="text-xs tracking-[0.25em] text-[#D946EF]">PROJECTS</h3>
            <ul className="mt-3 flex flex-wrap gap-4">
              {RESUME_PROJECTS.map((project) => (
                <li key={project} className="text-sm text-zinc-300">
                  {project}
                </li>
              ))}
            </ul>
          </GlassPanel>
        </div>

        <div className="flex flex-col items-center gap-2 pt-4 text-center">
          {RESUME_FILE_URL ? (
            <a
              href={RESUME_FILE_URL}
              download
              className="inline-flex items-center gap-2 rounded-full bg-gradient-to-r from-[#8B5CF6] via-[#A855F7] to-[#D946EF] px-7 py-3 text-sm tracking-widest text-white shadow-[0_0_24px_rgba(168,85,247,0.35)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white"
            >
              DOWNLOAD RESUME →
            </a>
          ) : (
            <span
              aria-disabled="true"
              title="No resume file has been added to the project yet"
              className="inline-flex cursor-not-allowed items-center gap-2 rounded-full border border-white/15 px-7 py-3 text-sm tracking-widest text-zinc-500"
            >
              RESUME FILE COMING SOON
            </span>
          )}
        </div>
      </div>
    </div>
  );
}
