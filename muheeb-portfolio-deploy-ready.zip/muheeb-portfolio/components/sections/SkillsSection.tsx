"use client";

import SectionLabel from "@/components/ui/SectionLabel";
import { useExperience } from "@/components/experience/ExperienceContext";

interface Cluster {
  id: string;
  title: string;
  dominant?: boolean;
  skills: string[];
}

const CLUSTERS: Cluster[] = [
  {
    id: "growth",
    title: "GROWTH",
    dominant: true,
    skills: ["Performance Marketing", "Meta Ads", "Campaign Strategy", "Traffic Campaigns"],
  },
  {
    id: "web",
    title: "WEB",
    skills: ["Web Development", "WordPress", "Shopify", "Website Design"],
  },
  {
    id: "search",
    title: "SEARCH",
    skills: ["SEO", "Search Console", "Semrush"],
  },
  {
    id: "creative",
    title: "CREATIVE",
    skills: ["Video Editing", "Graphic Design", "AI Content", "Content Creation", "Creative Ideation"],
  },
];

function ClusterCard({ cluster }: { cluster: Cluster }) {
  const { hoveredCluster, setHoveredCluster } = useExperience();
  const isActive = hoveredCluster === cluster.id;

  return (
    <button
      type="button"
      onMouseEnter={() => setHoveredCluster(cluster.id)}
      onMouseLeave={() => setHoveredCluster(null)}
      onFocus={() => setHoveredCluster(cluster.id)}
      onBlur={() => setHoveredCluster(null)}
      className={`flex w-full flex-col items-start gap-2 rounded-2xl border px-5 py-4 text-left backdrop-blur-md transition-all duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#A855F7] ${
        cluster.dominant ? "sm:py-6" : ""
      } ${
        isActive
          ? "border-[#A855F7]/60 bg-white/[0.06] shadow-[0_0_30px_rgba(168,85,247,0.35)]"
          : "border-white/[0.08] bg-white/[0.03]"
      }`}
    >
      <span
        className={`text-xs tracking-[0.3em] ${
          cluster.dominant ? "text-[#D946EF]" : "text-zinc-400"
        }`}
      >
        {cluster.title}
      </span>
      <ul className="flex flex-wrap gap-x-3 gap-y-1 text-sm text-zinc-200">
        {cluster.skills.map((skill) => (
          <li key={skill}>{skill}</li>
        ))}
      </ul>
    </button>
  );
}

export default function SkillsSection() {
  const dominant = CLUSTERS.find((c) => c.dominant)!;
  const rest = CLUSTERS.filter((c) => !c.dominant);

  return (
    <div id="skills" className="relative flex h-full w-full items-center justify-center px-6">
      <div className="mx-auto flex w-full max-w-4xl flex-col items-center gap-8">
        <div className="flex flex-col items-center gap-3 text-center">
          <SectionLabel>Toolkit</SectionLabel>
          <h2 className="text-3xl font-semibold text-white sm:text-4xl lg:text-5xl">
            MY DIGITAL TOOLKIT
          </h2>
          <p className="max-w-md text-sm text-zinc-400 sm:text-base">
            A combination of marketing, technology, search and creative skills.
          </p>
        </div>

        {/* Desktop/tablet: dominant Growth cluster up top, the other three
            below it — an intentional hub layout, not a plain equal-weight grid. */}
        <div className="hidden w-full flex-col items-center gap-4 sm:flex">
          <div className="w-full max-w-md">
            <ClusterCard cluster={dominant} />
          </div>
          <div className="grid w-full grid-cols-1 gap-4 md:grid-cols-3">
            {rest.map((c) => (
              <ClusterCard key={c.id} cluster={c} />
            ))}
          </div>
        </div>

        {/* Mobile: single accessible column, dominant cluster still first
            and visually distinct rather than a naive vertical stack. */}
        <div className="flex w-full flex-col gap-3 sm:hidden">
          <ClusterCard cluster={dominant} />
          {rest.map((c) => (
            <ClusterCard key={c.id} cluster={c} />
          ))}
        </div>
      </div>
    </div>
  );
}
