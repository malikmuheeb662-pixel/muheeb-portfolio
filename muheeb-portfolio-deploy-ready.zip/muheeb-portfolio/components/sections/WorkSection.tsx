"use client";

import SectionLabel from "@/components/ui/SectionLabel";
import GlassPanel from "@/components/ui/GlassPanel";
import ProjectPreviewPlaceholder from "./ProjectPreviewPlaceholder";
import { useExperience } from "@/components/experience/ExperienceContext";

interface Project {
  id: string;
  label: string;
  title: string;
  description: string;
  tags: string[];
}

// Exact order and copy as specified: Mubix Digital (flagship) -> DIDM Kalkaji -> Krypt.
const PROJECTS: Project[] = [
  {
    id: "mubix-digital",
    label: "01 / DIGITAL GROWTH",
    title: "Mubix Digital",
    description:
      "A complete digital presence built from the ground up — including website design and development, SEO, branding, creative production, content, AI-generated visuals and Meta traffic campaigns.",
    tags: ["Web Development", "SEO", "Meta Ads", "Branding", "Creative", "AI Content"],
  },
  {
    id: "didm-kalkaji",
    label: "02 / WEB EXPERIENCE",
    title: "DIDM Kalkaji",
    description:
      "A modern education-focused website experience designed and developed for the DIDM Kalkaji centre, with a strong focus on course presentation, visual hierarchy and conversion-oriented structure.",
    tags: ["Web Design", "Web Development", "UI/UX", "Education", "Conversion-focused Design"],
  },
  {
    id: "krypt",
    label: "03 / E-COMMERCE",
    title: "Krypt",
    description:
      "A Shopify e-commerce experience covering store design, theme customization, product presentation, creative assets and SEO.",
    tags: ["Shopify", "E-commerce", "Theme Customization", "Product Pages", "Creative", "SEO"],
  },
];

import type { ProjectId } from "@/lib/caseStudies";

function ProjectCard({ project, index }: { project: Project; index: number }) {
  const {
    hoveredProject,
    setHoveredProject,
    selectedProject,
    setSelectedProject,
    setOpenCaseStudy,
  } = useExperience();

  const isSelected = selectedProject === project.id;
  const isDimmed = selectedProject !== null && !isSelected;
  const isFlagship = index === 0;

  function toggleSelected() {
    setSelectedProject(isSelected ? null : project.id);
  }

  return (
    <li>
      <GlassPanel
        className={`overflow-hidden transition-all duration-300 ease-out ${
          isSelected ? "border-[#A855F7]/50 shadow-[0_0_40px_rgba(168,85,247,0.25)]" : ""
        }`}
      >
        <div
          className={`transition-opacity duration-300 ${isDimmed ? "opacity-45" : "opacity-100"}`}
        >
          <button
            type="button"
            aria-pressed={isSelected}
            aria-label={`${isSelected ? "Hide" : "View"} details for ${project.title}`}
            onMouseEnter={() => setHoveredProject(project.id)}
            onMouseLeave={() => setHoveredProject(null)}
            onFocus={() => setHoveredProject(project.id)}
            onBlur={() => setHoveredProject(null)}
            onClick={toggleSelected}
            className={`grid w-full grid-cols-1 gap-5 p-5 text-left focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#A855F7] sm:grid-cols-[1.1fr_1.4fr] sm:p-6 ${
              hoveredProject === project.id && !isSelected ? "bg-white/[0.02]" : ""
            }`}
          >
            <div className={isFlagship ? "sm:min-h-[180px]" : "sm:min-h-[140px]"}>
              <ProjectPreviewPlaceholder />
            </div>

            <div className="flex flex-col gap-3">
              <p className="text-xs tracking-[0.25em] text-[#D946EF]">{project.label}</p>
              <h3
                className={`font-semibold text-white ${
                  isFlagship ? "text-2xl sm:text-3xl" : "text-xl sm:text-2xl"
                }`}
              >
                {project.title}
              </h3>
              <p className="text-sm leading-relaxed text-zinc-400">{project.description}</p>
              <ul className="flex flex-wrap gap-2 pt-1">
                {project.tags.map((tag) => (
                  <li
                    key={tag}
                    className="rounded-full border border-white/10 bg-white/[0.03] px-3 py-1 text-[11px] tracking-wide text-zinc-300"
                  >
                    {tag}
                  </li>
                ))}
              </ul>
            </div>
          </button>

          {isSelected && (
            <div className="flex items-center gap-3 px-5 pb-5 sm:px-6 sm:pb-6">
              <button
                type="button"
                onClick={() => setOpenCaseStudy(project.id as ProjectId)}
                aria-label={`Open the ${project.title} case study`}
                className="inline-flex items-center gap-2 rounded-full border border-[#A855F7]/40 px-5 py-2 text-xs tracking-widest text-white shadow-[0_0_18px_rgba(168,85,247,0.25)] transition-shadow duration-300 hover:shadow-[0_0_28px_rgba(168,85,247,0.4)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#A855F7]"
              >
                VIEW CASE STUDY →
              </button>
            </div>
          )}
        </div>
      </GlassPanel>
    </li>
  );
}

export default function WorkSection() {
  return (
    <div id="work" className="relative flex h-full w-full items-center justify-center overflow-y-auto px-6 py-16">
      <div className="mx-auto flex w-full max-w-4xl flex-col gap-8">
        <div className="flex flex-col items-center gap-3 text-center">
          <SectionLabel>Work</SectionLabel>
          <h2 className="text-3xl font-semibold text-white sm:text-4xl lg:text-5xl">
            SELECTED WORK
          </h2>
          <p className="max-w-lg text-sm text-zinc-400 sm:text-base">
            Real projects built across digital marketing, web, SEO, e-commerce and creative
            production.
          </p>
        </div>

        <ol className="flex flex-col gap-5">
          {PROJECTS.map((project, i) => (
            <ProjectCard key={project.id} project={project} index={i} />
          ))}
        </ol>
      </div>
    </div>
  );
}
