"use client";

import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

// One node per timeline step (B.Com, MBA, 15 May 2026, DIDM, Real Projects, Current Focus).
const NODE_Y_POSITIONS = [-1.4, -0.6, 0.2, 1.0, 1.8, 2.6];

interface AboutTimeline3DProps {
  localProgress?: number;
}

/**
 * A vertical column of glowing nodes representing Muheeb's journey timeline,
 * positioned where the camera drifts through the About zone. The node
 * nearest the current scroll position brightens and scales up, echoing the
 * highlighted step in the DOM timeline without duplicating the scroll logic.
 */
export default function AboutTimeline3D({ localProgress = 0 }: AboutTimeline3DProps) {
  const groupRef = useRef<THREE.Group>(null);
  const activeIndex = Math.min(
    NODE_Y_POSITIONS.length - 1,
    Math.floor(localProgress * NODE_Y_POSITIONS.length)
  );

  useFrame(() => {
    if (!groupRef.current) return;
    groupRef.current.children.forEach((child, i) => {
      const mesh = child as THREE.Mesh;
      const material = mesh.material as THREE.MeshStandardMaterial | undefined;
      if (!material) return;
      const isActive = i === activeIndex;
      material.emissiveIntensity = THREE.MathUtils.lerp(
        material.emissiveIntensity,
        isActive ? 1.2 : 0.35,
        0.08
      );
      const targetScale = isActive ? 1.3 : 0.85;
      mesh.scale.setScalar(THREE.MathUtils.lerp(mesh.scale.x, targetScale, 0.08));
    });
  });

  return (
    <group ref={groupRef} position={[1.7, 0, -1.4]}>
      {NODE_Y_POSITIONS.map((y, i) => (
        <mesh key={i} position={[0, y, 0]}>
          <sphereGeometry args={[0.16, 24, 24]} />
          <meshStandardMaterial
            color="#0A0A0D"
            emissive="#A855F7"
            emissiveIntensity={0.35}
            metalness={0.7}
            roughness={0.25}
          />
        </mesh>
      ))}
    </group>
  );
}
