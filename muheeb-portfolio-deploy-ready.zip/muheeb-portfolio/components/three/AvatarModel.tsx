"use client";

import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

/**
 * Reusable avatar component. Currently renders a tasteful abstract humanoid
 * silhouette placeholder. Swap the internals with a loaded .glb/.gltf model
 * (via useGLTF from drei) once the final asset is available — the parent
 * <AvatarTransition /> interface will not need to change.
 */
export default function AvatarModel() {
  const groupRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (!groupRef.current) return;
    const t = state.clock.getElapsedTime();
    groupRef.current.rotation.y = Math.sin(t * 0.15) * 0.15;
  });

  return (
    <group ref={groupRef} position={[0, -0.4, 0]}>
      {/* Head */}
      <mesh position={[0, 1.55, 0]}>
        <sphereGeometry args={[0.28, 32, 32]} />
        <meshStandardMaterial
          color="#0A0A0D"
          emissive="#8B5CF6"
          emissiveIntensity={0.5}
          metalness={0.7}
          roughness={0.2}
        />
      </mesh>
      {/* Torso - abstract silhouette */}
      <mesh position={[0, 0.7, 0]}>
        <capsuleGeometry args={[0.42, 1.1, 8, 16]} />
        <meshStandardMaterial
          color="#050505"
          emissive="#A855F7"
          emissiveIntensity={0.25}
          metalness={0.8}
          roughness={0.3}
          transparent
          opacity={0.9}
        />
      </mesh>
      {/* Rim light accent ring */}
      <mesh position={[0, 0.7, 0]} rotation={[Math.PI / 2, 0, 0]}>
        <ringGeometry args={[0.55, 0.58, 48]} />
        <meshBasicMaterial color="#D946EF" transparent opacity={0.35} side={THREE.DoubleSide} />
      </mesh>
    </group>
  );
}
