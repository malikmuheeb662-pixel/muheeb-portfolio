"use client";

import { useFrame } from "@react-three/fiber";
import { useMouseParallax } from "@/hooks/useMouseParallax";
import { MutableRefObject } from "react";
import * as THREE from "three";
import {
  HERO_END,
  ABOUT_END,
  SKILLS_END,
  WORK_END,
  JOURNEY_END,
  CERTS_END,
  RESUME_END,
  CONTACT_END,
} from "@/lib/zones";
import type { ProjectId } from "@/lib/caseStudies";
import { ENV_OFFSETS } from "./CaseStudyEnvironments3D";

interface CameraRigProps {
  scrollProgress: MutableRefObject<number>;
  reducedMotion?: boolean;
  caseStudyId?: ProjectId | null;
  caseStudyProgress?: MutableRefObject<number>;
}

interface Keyframe {
  p: number;
  pos: [number, number, number];
  look: [number, number, number];
}

// One continuous path through all nine journey zones: Hero (avatar) -> About
// (timeline column) -> Skills (cluster universe) -> Work (project gallery) ->
// Journey (milestone path) -> Certifications (credential frames) -> Resume
// (document) -> Contact (communication hub) -> Final CTA (closing shot).
// No hard cuts — the camera glides between these anchors as a direct
// function of scroll position.
const KEYFRAMES: Keyframe[] = [
  { p: 0, pos: [0, 0.2, 5], look: [0, 0.4, 0] },
  { p: HERO_END, pos: [0, 0.6, 1.2], look: [0.6, 0.6, -1] },
  { p: ABOUT_END, pos: [0, 0.2, -3.5], look: [0, 0, -6.5] },
  { p: SKILLS_END, pos: [0, -0.1, -6.2], look: [0, -0.2, -9] },
  { p: WORK_END, pos: [0, 0.15, -12.8], look: [0, 0.05, -15.5] },
  { p: JOURNEY_END, pos: [0, 0.25, -19.5], look: [0, 0.05, -22] },
  { p: CERTS_END, pos: [0, 0.15, -24.5], look: [0, -0.05, -27] },
  { p: RESUME_END, pos: [0, 0.05, -29], look: [0, -0.1, -31.5] },
  { p: CONTACT_END, pos: [0, 0.15, -34], look: [0, 0, -37] },
  { p: 1, pos: [0, 0.05, -38], look: [0, -0.05, -41] },
];

function sampleKeyframes(p: number): { pos: [number, number, number]; look: [number, number, number] } {
  for (let i = 0; i < KEYFRAMES.length - 1; i++) {
    const a = KEYFRAMES[i];
    const b = KEYFRAMES[i + 1];
    if (p >= a.p && p <= b.p) {
      const t = (p - a.p) / (b.p - a.p || 1);
      return {
        pos: [
          THREE.MathUtils.lerp(a.pos[0], b.pos[0], t),
          THREE.MathUtils.lerp(a.pos[1], b.pos[1], t),
          THREE.MathUtils.lerp(a.pos[2], b.pos[2], t),
        ],
        look: [
          THREE.MathUtils.lerp(a.look[0], b.look[0], t),
          THREE.MathUtils.lerp(a.look[1], b.look[1], t),
          THREE.MathUtils.lerp(a.look[2], b.look[2], t),
        ],
      };
    }
  }
  const last = KEYFRAMES[KEYFRAMES.length - 1];
  return { pos: last.pos, look: last.look };
}

/** Entry anchor (localProgress 0) and immersed anchor (localProgress 1) per case study. */
function sampleCaseStudy(
  id: ProjectId,
  localProgress: number
): { pos: [number, number, number]; look: [number, number, number] } {
  const [ox, oy, oz] = ENV_OFFSETS[id];
  const entryPos: [number, number, number] = [ox, oy + 0.3, oz + 3];
  const entryLook: [number, number, number] = [ox, oy, oz];
  const immersedPos: [number, number, number] = [ox, oy + 0.5, oz + 1.4];
  const immersedLook: [number, number, number] = [ox, oy + 0.2, oz - 0.5];

  const t = Math.min(1, Math.max(0, localProgress));
  return {
    pos: [
      THREE.MathUtils.lerp(entryPos[0], immersedPos[0], t),
      THREE.MathUtils.lerp(entryPos[1], immersedPos[1], t),
      THREE.MathUtils.lerp(entryPos[2], immersedPos[2], t),
    ],
    look: [
      THREE.MathUtils.lerp(entryLook[0], immersedLook[0], t),
      THREE.MathUtils.lerp(entryLook[1], immersedLook[1], t),
      THREE.MathUtils.lerp(entryLook[2], immersedLook[2], t),
    ],
  };
}

export default function CameraRig({
  scrollProgress,
  reducedMotion = false,
  caseStudyId = null,
  caseStudyProgress,
}: CameraRigProps) {
  const mouse = useMouseParallax();

  useFrame((state) => {
    const { camera } = state;

    const { pos, look } = caseStudyId
      ? sampleCaseStudy(caseStudyId, caseStudyProgress?.current ?? 0)
      : sampleKeyframes(scrollProgress.current);

    const parallaxX = reducedMotion ? 0 : mouse.current.x * 0.25;
    const parallaxY = reducedMotion ? 0 : -mouse.current.y * 0.15;
    const smoothing = reducedMotion ? 0.6 : 0.05;

    camera.position.x += (pos[0] + parallaxX - camera.position.x) * smoothing;
    camera.position.y += (pos[1] + parallaxY - camera.position.y) * smoothing;
    camera.position.z += (pos[2] - camera.position.z) * Math.max(smoothing, 0.06);

    camera.lookAt(look[0], look[1], look[2]);
  });

  return null;
}
