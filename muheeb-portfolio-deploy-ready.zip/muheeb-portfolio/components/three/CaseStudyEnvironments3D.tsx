"use client";

import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import type { ProjectId } from "@/lib/caseStudies";

// Each environment sits at its own x-offset, well beyond the Work gallery
// (which ends around z=-13), so opening a case study never visually
// collides with the journey content behind it.
const ENV_OFFSETS: Record<ProjectId, [number, number, number]> = {
  "mubix-digital": [-8, 0, -19],
  "didm-kalkaji": [0, 0, -19],
  krypt: [8, 0, -19],
};

function useGentleSpin(speed = 0.05) {
  const ref = useRef<THREE.Group>(null);
  useFrame((state) => {
    if (!ref.current) return;
    ref.current.rotation.y = state.clock.getElapsedTime() * speed;
  });
  return ref;
}

/** Website panel + SEO node + campaign panel + creative tile — all abstract. */
function MubixEnvironment({ offset }: { offset: [number, number, number] }) {
  const ref = useGentleSpin(0.04);
  return (
    <group ref={ref} position={offset}>
      <mesh position={[-0.6, 0.4, 0]}>
        <planeGeometry args={[1.1, 0.7]} />
        <meshStandardMaterial
          color="#0A0A0D"
          emissive="#8B5CF6"
          emissiveIntensity={0.45}
          metalness={0.5}
          roughness={0.2}
          transparent
          opacity={0.6}
          side={THREE.DoubleSide}
        />
      </mesh>
      <mesh position={[0.7, -0.2, 0.3]}>
        <icosahedronGeometry args={[0.35, 1]} />
        <meshStandardMaterial color="#0A0A0D" emissive="#A855F7" emissiveIntensity={0.5} metalness={0.7} roughness={0.25} />
      </mesh>
      <mesh position={[-0.3, -0.7, -0.4]}>
        <boxGeometry args={[0.5, 0.5, 0.5]} />
        <meshStandardMaterial color="#0A0A0D" emissive="#D946EF" emissiveIntensity={0.4} wireframe metalness={0.5} roughness={0.3} />
      </mesh>
      <mesh position={[0.9, 0.7, -0.5]}>
        <torusGeometry args={[0.3, 0.1, 16, 32]} />
        <meshStandardMaterial color="#0A0A0D" emissive="#A855F7" emissiveIntensity={0.45} metalness={0.6} roughness={0.25} />
      </mesh>
    </group>
  );
}

/** Floating course cards + structured info block + education geometry. */
function DidmEnvironment({ offset }: { offset: [number, number, number] }) {
  const ref = useGentleSpin(0.035);
  return (
    <group ref={ref} position={offset}>
      {[-0.7, 0, 0.7].map((x, i) => (
        <mesh key={i} position={[x, Math.sin(i) * 0.2, i * 0.2 - 0.2]}>
          <boxGeometry args={[0.5, 0.65, 0.04]} />
          <meshStandardMaterial
            color="#0A0A0D"
            emissive="#8B5CF6"
            emissiveIntensity={0.4}
            metalness={0.5}
            roughness={0.2}
          />
        </mesh>
      ))}
      <mesh position={[0, -0.9, -0.6]}>
        <planeGeometry args={[1.6, 0.3]} />
        <meshStandardMaterial
          color="#0A0A0D"
          emissive="#A855F7"
          emissiveIntensity={0.4}
          transparent
          opacity={0.6}
          side={THREE.DoubleSide}
        />
      </mesh>
      <mesh position={[0, 0.9, -0.5]}>
        <octahedronGeometry args={[0.3]} />
        <meshStandardMaterial color="#0A0A0D" emissive="#D946EF" emissiveIntensity={0.45} metalness={0.6} roughness={0.25} />
      </mesh>
    </group>
  );
}

/** Product-card grid + storefront panel + e-commerce abstract shape. */
function KryptEnvironment({ offset }: { offset: [number, number, number] }) {
  const ref = useGentleSpin(0.045);
  return (
    <group ref={ref} position={offset}>
      {[-0.5, 0.5].map((x) =>
        [-0.35, 0.35].map((y) => (
          <mesh key={`${x}-${y}`} position={[x, y, 0]}>
            <boxGeometry args={[0.4, 0.4, 0.06]} />
            <meshStandardMaterial
              color="#0A0A0D"
              emissive="#A855F7"
              emissiveIntensity={0.4}
              metalness={0.6}
              roughness={0.2}
            />
          </mesh>
        ))
      )}
      <mesh position={[0, 0, -0.6]}>
        <planeGeometry args={[1.6, 1.2]} />
        <meshStandardMaterial
          color="#0A0A0D"
          emissive="#8B5CF6"
          emissiveIntensity={0.35}
          transparent
          opacity={0.5}
          side={THREE.DoubleSide}
        />
      </mesh>
      <mesh position={[0, 0, 0.5]}>
        <torusKnotGeometry args={[0.22, 0.07, 64, 8]} />
        <meshStandardMaterial color="#0A0A0D" emissive="#D946EF" emissiveIntensity={0.5} metalness={0.7} roughness={0.2} />
      </mesh>
    </group>
  );
}

interface CaseStudyEnvironments3DProps {
  activeId: ProjectId | null;
}

/**
 * Three abstract, atmosphere-only environments — one per case study. None of
 * this renders fabricated analytics/screenshots; it's purely decorative
 * geometry standing in for "a digital growth command center", "an education
 * environment", and "an e-commerce showroom" respectively, per the brief.
 * All three are always mounted (cheap, simple geometry) and crossfaded via
 * scale, matching the pattern used for the journey zones.
 */
export default function CaseStudyEnvironments3D({ activeId }: CaseStudyEnvironments3DProps) {
  return (
    <>
      <group scale={activeId === "mubix-digital" ? 1 : 0} visible={activeId === "mubix-digital"}>
        <MubixEnvironment offset={ENV_OFFSETS["mubix-digital"]} />
      </group>
      <group scale={activeId === "didm-kalkaji" ? 1 : 0} visible={activeId === "didm-kalkaji"}>
        <DidmEnvironment offset={ENV_OFFSETS["didm-kalkaji"]} />
      </group>
      <group scale={activeId === "krypt" ? 1 : 0} visible={activeId === "krypt"}>
        <KryptEnvironment offset={ENV_OFFSETS.krypt} />
      </group>
    </>
  );
}

export { ENV_OFFSETS };
