"use client";

import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

const FRAME_POSITIONS: [number, number, number][] = [
  [-2, 0.1, -21.5],
  [0, -0.15, -22],
  [2, 0.1, -21.5],
];

// Shared across all three frames (same dimensions) and created once at
// module scope rather than per-render, avoiding needless dispose/recreate
// churn while the shared Scene re-renders on every scroll-driven update.
const FRAME_EDGES = new THREE.PlaneGeometry(0.9, 1.2);

function CertificateFrame({ position }: { position: [number, number, number] }) {
  const ref = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (!ref.current) return;
    const t = state.clock.getElapsedTime();
    ref.current.position.y = position[1] + Math.sin(t * 0.3 + position[0]) * 0.08;
  });

  return (
    <group ref={ref} position={position}>
      <mesh>
        <planeGeometry args={[0.9, 1.2]} />
        <meshStandardMaterial
          color="#0A0A0D"
          emissive="#8B5CF6"
          emissiveIntensity={0.35}
          metalness={0.5}
          roughness={0.2}
          transparent
          opacity={0.5}
          side={THREE.DoubleSide}
        />
      </mesh>
      <lineSegments>
        <edgesGeometry args={[FRAME_EDGES]} />
        <lineBasicMaterial color="#A855F7" transparent opacity={0.6} />
      </lineSegments>
      {/* Abstract holographic lines — never a rendered "certificate". */}
      {[-0.3, -0.1, 0.1].map((y, i) => (
        <mesh key={i} position={[0, y, 0.01]}>
          <planeGeometry args={[0.5, 0.02]} />
          <meshBasicMaterial color="#D946EF" transparent opacity={0.35} />
        </mesh>
      ))}
    </group>
  );
}

/**
 * Purely abstract credential atmosphere: floating glass frames with
 * holographic line accents. Never renders anything resembling a real
 * certificate image or text.
 */
export default function CertificationEnvironment3D() {
  return (
    <group>
      {FRAME_POSITIONS.map((pos, i) => (
        <CertificateFrame key={i} position={pos} />
      ))}
    </group>
  );
}
