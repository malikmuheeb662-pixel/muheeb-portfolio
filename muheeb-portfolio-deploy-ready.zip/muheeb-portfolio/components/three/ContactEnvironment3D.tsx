"use client";

import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

const HUB_POSITION: [number, number, number] = [0, 0, -32];

/**
 * A digital communication hub: a glowing central node with orbiting signal
 * rings and a few floating glass panels. Purely abstract — no real contact
 * details (email/phone/handles) ever render inside WebGL.
 */
export default function ContactEnvironment3D() {
  const nodeRef = useRef<THREE.Mesh>(null);
  const ring1Ref = useRef<THREE.Mesh>(null);
  const ring2Ref = useRef<THREE.Mesh>(null);

  useFrame((state) => {
    const t = state.clock.getElapsedTime();
    if (nodeRef.current) {
      const material = nodeRef.current.material as THREE.MeshStandardMaterial;
      material.emissiveIntensity = 0.6 + Math.sin(t * 0.8) * 0.15;
    }
    if (ring1Ref.current) ring1Ref.current.rotation.z = t * 0.15;
    if (ring2Ref.current) ring2Ref.current.rotation.x = t * 0.12;
  });

  return (
    <group position={HUB_POSITION}>
      <mesh ref={nodeRef}>
        <sphereGeometry args={[0.35, 32, 32]} />
        <meshStandardMaterial
          color="#0A0A0D"
          emissive="#D946EF"
          emissiveIntensity={0.6}
          metalness={0.7}
          roughness={0.2}
        />
      </mesh>

      <mesh ref={ring1Ref}>
        <torusGeometry args={[0.75, 0.02, 16, 64]} />
        <meshBasicMaterial color="#A855F7" transparent opacity={0.5} />
      </mesh>
      <mesh ref={ring2Ref} rotation={[Math.PI / 3, 0, 0]}>
        <torusGeometry args={[1.05, 0.015, 16, 64]} />
        <meshBasicMaterial color="#8B5CF6" transparent opacity={0.4} />
      </mesh>

      {[-1.3, 1.3].map((x, i) => (
        <mesh key={i} position={[x, i === 0 ? 0.4 : -0.4, -0.5]}>
          <planeGeometry args={[0.7, 0.9]} />
          <meshStandardMaterial
            color="#0A0A0D"
            emissive="#8B5CF6"
            emissiveIntensity={0.35}
            transparent
            opacity={0.4}
            side={THREE.DoubleSide}
          />
        </mesh>
      ))}
    </group>
  );
}
