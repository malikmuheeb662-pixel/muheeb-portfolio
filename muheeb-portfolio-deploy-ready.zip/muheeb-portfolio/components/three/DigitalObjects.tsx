"use client";

import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

interface FloatingShapeProps {
  position: [number, number, number];
  geometry: "box" | "torus" | "octahedron" | "plane";
  speed?: number;
  scale?: number;
}

function FloatingShape({ position, geometry, speed = 1, scale = 1 }: FloatingShapeProps) {
  const ref = useRef<THREE.Mesh>(null);
  // eslint-disable-next-line react-hooks/purity -- one-time randomization per mount, client-only render inside <Scene />
  const offset = useRef(Math.random() * Math.PI * 2);

  useFrame((state) => {
    if (!ref.current) return;
    const t = state.clock.getElapsedTime() * speed + offset.current;
    ref.current.position.y = position[1] + Math.sin(t) * 0.25;
    ref.current.rotation.x = t * 0.15;
    ref.current.rotation.y = t * 0.2;
  });

  return (
    <mesh ref={ref} position={position} scale={scale}>
      {geometry === "box" && <boxGeometry args={[0.6, 0.6, 0.6]} />}
      {geometry === "torus" && <torusGeometry args={[0.4, 0.14, 16, 32]} />}
      {geometry === "octahedron" && <octahedronGeometry args={[0.5]} />}
      {geometry === "plane" && <planeGeometry args={[0.9, 0.6]} />}
      <meshStandardMaterial
        color="#0A0A0D"
        emissive="#A855F7"
        emissiveIntensity={0.4}
        metalness={0.6}
        roughness={0.25}
        wireframe={geometry === "box"}
      />
    </mesh>
  );
}

/**
 * Abstract UI-representative floating objects: browser window, graph, ad panel,
 * e-commerce card, creative frame, data visualization — no brand logos.
 */
export default function DigitalObjects({ simplify = false }: { simplify?: boolean }) {
  return (
    <group>
      <FloatingShape position={[-3.2, 1.2, -2]} geometry="plane" speed={0.6} />
      <FloatingShape position={[3, -0.8, -1.5]} geometry="torus" speed={0.8} />
      {!simplify && (
        <>
          <FloatingShape position={[-2.2, -1.6, -3]} geometry="octahedron" speed={0.5} />
          <FloatingShape position={[2.8, 1.6, -3.5]} geometry="box" speed={0.7} scale={0.8} />
          <FloatingShape position={[0, -2.2, -4]} geometry="plane" speed={0.4} scale={0.7} />
        </>
      )}
    </group>
  );
}
