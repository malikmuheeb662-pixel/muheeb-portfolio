"use client";

import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

const CORE_POSITION: [number, number, number] = [0, 0, -39];

/**
 * The portfolio's closing shot: one large abstract node with a strong purple
 * glow and a slow-drifting particle halo. Deliberately the most cinematic
 * moment in the experience, and deliberately restrained — a single object,
 * not a cluttered scene.
 */
export default function FinalCTAEnvironment3D() {
  const coreRef = useRef<THREE.Mesh>(null);
  const haloRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    const t = state.clock.getElapsedTime();
    if (coreRef.current) {
      coreRef.current.rotation.y = t * 0.05;
      const material = coreRef.current.material as THREE.MeshStandardMaterial;
      material.emissiveIntensity = 0.75 + Math.sin(t * 0.5) * 0.15;
    }
    if (haloRef.current) {
      haloRef.current.rotation.y = -t * 0.03;
    }
  });

  const haloPoints = Array.from({ length: 24 }, (_, i) => {
    const angle = (i / 24) * Math.PI * 2;
    const radius = 1.6 + Math.sin(i) * 0.3;
    return [Math.cos(angle) * radius, Math.sin(i * 1.7) * 0.8, Math.sin(angle) * radius] as [
      number,
      number,
      number,
    ];
  });

  return (
    <group position={CORE_POSITION}>
      <mesh ref={coreRef}>
        <icosahedronGeometry args={[0.6, 1]} />
        <meshStandardMaterial
          color="#0A0A0D"
          emissive="#D946EF"
          emissiveIntensity={0.75}
          metalness={0.75}
          roughness={0.15}
        />
      </mesh>

      <group ref={haloRef}>
        {haloPoints.map((pos, i) => (
          <mesh key={i} position={pos}>
            <sphereGeometry args={[0.025, 8, 8]} />
            <meshBasicMaterial color="#A855F7" transparent opacity={0.55} />
          </mesh>
        ))}
      </group>
    </group>
  );
}
