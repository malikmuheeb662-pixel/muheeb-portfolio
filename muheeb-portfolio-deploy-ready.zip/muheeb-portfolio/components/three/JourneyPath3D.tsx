"use client";

import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { JOURNEY_MILESTONES } from "@/lib/journey";
import { useExperience } from "@/components/experience/ExperienceContext";

// A gentle drifting line of milestone nodes, positioned right after the
// Work gallery (which ends around z=-13) and before the Certifications
// environment. x oscillates slightly so the path reads as a route through
// space rather than a static column.
const NODES = JOURNEY_MILESTONES.map((m, i) => ({
  id: m.id,
  position: [i % 2 === 0 ? 0.6 : -0.6, 0.15 * Math.sin(i), -13.5 - i * 0.9] as [
    number,
    number,
    number,
  ],
}));

interface JourneyPath3DProps {
  localProgress?: number;
}

export default function JourneyPath3D({ localProgress = 0 }: JourneyPath3DProps) {
  const groupRef = useRef<THREE.Group>(null);
  const { hoveredMilestone } = useExperience();
  const activeIndex = Math.min(NODES.length - 1, Math.floor(localProgress * NODES.length));

  useFrame(() => {
    if (!groupRef.current) return;
    groupRef.current.children.forEach((child, i) => {
      const mesh = child as THREE.Mesh;
      const material = mesh.material as THREE.MeshStandardMaterial | undefined;
      if (!material) return;
      const node = NODES[i];
      const isScrollActive = i === activeIndex;
      const isHovered = hoveredMilestone === node.id;
      const isActive = isScrollActive || isHovered;

      material.emissiveIntensity = THREE.MathUtils.lerp(
        material.emissiveIntensity,
        isActive ? 1.2 : 0.35,
        0.08
      );
      const targetScale = isActive ? 1.3 : 0.8;
      mesh.scale.setScalar(THREE.MathUtils.lerp(mesh.scale.x, targetScale, 0.08));
    });
  });

  return (
    <group ref={groupRef}>
      {NODES.map((node) => (
        <mesh key={node.id} position={node.position}>
          <icosahedronGeometry args={[0.2, 0]} />
          <meshStandardMaterial
            color="#0A0A0D"
            emissive="#A855F7"
            emissiveIntensity={0.35}
            metalness={0.65}
            roughness={0.25}
          />
        </mesh>
      ))}
    </group>
  );
}
