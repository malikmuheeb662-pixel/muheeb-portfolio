export default function Lighting() {
  return (
    <>
      <ambientLight intensity={0.25} />
      <pointLight position={[4, 3, 5]} intensity={40} color="#A855F7" distance={20} />
      <pointLight position={[-5, -2, -4]} intensity={25} color="#8B5CF6" distance={20} />
      <pointLight position={[0, 5, -6]} intensity={15} color="#D946EF" distance={25} />
      <hemisphereLight args={["#3a2560", "#050505", 0.3]} />
    </>
  );
}
