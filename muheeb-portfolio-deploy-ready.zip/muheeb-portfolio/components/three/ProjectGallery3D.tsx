"use client";

import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useExperience } from "@/components/experience/ExperienceContext";

interface PanelDef {
  id: string;
  position: [number, number, number];
  width: number;
  height: number;
  color: string;
}

// Mubix Digital (flagship, larger + more central) -> DIDM Kalkaji -> Krypt,
// travelling deeper into the gallery in that order, matching the required
// project order and the flagship's stronger visual emphasis.
const PANELS: PanelDef[] = [
  { id: "mubix-digital", position: [0, 0.3, -9.4], width: 2.0, height: 1.25, color: "#D946EF" },
  { id: "didm-kalkaji", position: [-2.1, -0.2, -10.6], width: 1.5, height: 0.95, color: "#8B5CF6" },
  { id: "krypt", position: [2.1, -0.35, -11.8], width: 1.5, height: 0.95, color: "#A855F7" },
];

function ProjectPanel({ id, position, width, height, color }: PanelDef) {
  const { hoveredProject, selectedProject } = useExperience();
  const groupRef = useRef<THREE.Group>(null);
  const materialRef = useRef<THREE.MeshStandardMaterial>(null);
  const isActive = hoveredProject === id || selectedProject === id;
  // Memoized per panel size so it isn't disposed/recreated on every
  // re-render (Scene re-renders each scroll-driven progress update).
  const edgeGeometry = useMemo(() => new THREE.PlaneGeometry(width, height), [width, height]);

  useFrame((state) => {
    if (!groupRef.current || !materialRef.current) return;
    const t = state.clock.getElapsedTime();

    // Gentle drift so the gallery reads as alive, not static.
    groupRef.current.position.y = position[1] + Math.sin(t * 0.25 + position[0]) * 0.08;

    // On hover/selection: move slightly toward the camera and scale up.
    const targetZ = position[2] + (isActive ? 0.5 : 0);
    groupRef.current.position.z = THREE.MathUtils.lerp(groupRef.current.position.z, targetZ, 0.08);

    const targetScale = isActive ? 1.08 : 1;
    groupRef.current.scale.setScalar(
      THREE.MathUtils.lerp(groupRef.current.scale.x, targetScale, 0.08)
    );

    materialRef.current.emissiveIntensity = THREE.MathUtils.lerp(
      materialRef.current.emissiveIntensity,
      isActive ? 1.0 : 0.4,
      0.08
    );
  });

  return (
    <group ref={groupRef} position={position}>
      {/* Glass-like panel body */}
      <mesh>
        <planeGeometry args={[width, height]} />
        <meshStandardMaterial
          ref={materialRef}
          color="#0A0A0D"
          emissive={color}
          emissiveIntensity={0.4}
          metalness={0.5}
          roughness={0.15}
          transparent
          opacity={0.55}
          side={THREE.DoubleSide}
        />
      </mesh>
      {/* Thin glowing frame edge */}
      <lineSegments>
        <edgesGeometry args={[edgeGeometry]} />
        <lineBasicMaterial color={color} transparent opacity={0.6} />
      </lineSegments>
    </group>
  );
}

/**
 * Atmospheric-only 3D gallery — depth, glass panels, purple glow, and
 * hover/selection reactivity. All readable project copy (title, description,
 * tags, CTA) lives in the DOM <WorkSection />, per the requirement that
 * critical content never live exclusively inside WebGL.
 */
export default function ProjectGallery3D() {
  return (
    <group>
      {PANELS.map((p) => (
        <ProjectPanel key={p.id} {...p} />
      ))}
    </group>
  );
}
