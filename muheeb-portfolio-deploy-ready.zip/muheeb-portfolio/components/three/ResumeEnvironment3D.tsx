"use client";

import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";

const DOC_POSITION: [number, number, number] = [0, 0, -27];

/**
 * A large floating glass "document" with holographic line accents and a
 * few orbiting particles. Purely decorative — the actual resume content
 * (education, capabilities, projects) lives in <ResumeSection />'s DOM.
 */
export default function ResumeEnvironment3D() {
  const docRef = useRef<THREE.Group>(null);
  const particlesRef = useRef<THREE.Group>(null);
  // Memoized so the geometry isn't disposed/recreated on every re-render
  // (Scene re-renders each scroll-driven progress update).
  const docEdges = useMemo(() => new THREE.PlaneGeometry(1.6, 2.1), []);

  useFrame((state) => {
    const t = state.clock.getElapsedTime();
    if (docRef.current) {
      docRef.current.rotation.y = Math.sin(t * 0.1) * 0.08;
      docRef.current.position.y = DOC_POSITION[1] + Math.sin(t * 0.25) * 0.06;
    }
    if (particlesRef.current) {
      particlesRef.current.rotation.y = t * 0.06;
    }
  });

  const lineYs = [0.9, 0.65, 0.4, 0.15, -0.1, -0.35, -0.6];

  return (
    <group>
      <group ref={docRef} position={DOC_POSITION}>
        <mesh>
          <planeGeometry args={[1.6, 2.1]} />
          <meshStandardMaterial
            color="#0A0A0D"
            emissive="#8B5CF6"
            emissiveIntensity={0.3}
            metalness={0.4}
            roughness={0.15}
            transparent
            opacity={0.45}
            side={THREE.DoubleSide}
          />
        </mesh>
        <lineSegments>
          <edgesGeometry args={[docEdges]} />
          <lineBasicMaterial color="#A855F7" transparent opacity={0.5} />
        </lineSegments>
        {lineYs.map((y, i) => (
          <mesh key={i} position={[0, y, 0.01]}>
            <planeGeometry args={[i % 2 === 0 ? 1.1 : 0.8, 0.03]} />
            <meshBasicMaterial color="#D946EF" transparent opacity={0.3} />
          </mesh>
        ))}
      </group>

      <group ref={particlesRef} position={DOC_POSITION}>
        {Array.from({ length: 10 }).map((_, i) => {
          const angle = (i / 10) * Math.PI * 2;
          const radius = 1.3;
          return (
            <mesh key={i} position={[Math.cos(angle) * radius, Math.sin(angle * 1.3) * 0.6, Math.sin(angle) * radius]}>
              <sphereGeometry args={[0.02, 8, 8]} />
              <meshBasicMaterial color="#A855F7" transparent opacity={0.6} />
            </mesh>
          );
        })}
      </group>
    </group>
  );
}
