"use client";

import { Canvas } from "@react-three/fiber";
import { Suspense, MutableRefObject } from "react";
import Lighting from "./Lighting";
import Particles from "./Particles";
import DigitalObjects from "./DigitalObjects";
import AvatarModel from "./AvatarModel";
import CameraRig from "./CameraRig";
import AboutTimeline3D from "./AboutTimeline3D";
import SkillClusters3D from "./SkillClusters3D";
import ProjectGallery3D from "./ProjectGallery3D";
import CaseStudyEnvironments3D from "./CaseStudyEnvironments3D";
import JourneyPath3D from "./JourneyPath3D";
import CertificationEnvironment3D from "./CertificationEnvironment3D";
import ResumeEnvironment3D from "./ResumeEnvironment3D";
import ContactEnvironment3D from "./ContactEnvironment3D";
import FinalCTAEnvironment3D from "./FinalCTAEnvironment3D";
import type { ZoneOpacities } from "@/lib/zones";
import type { ProjectId } from "@/lib/caseStudies";

interface SceneProps {
  scrollProgress: MutableRefObject<number>;
  reducedMotion: boolean;
  isMobile?: boolean;
  zoneOpacities: ZoneOpacities;
  aboutLocalProgress?: number;
  journeyLocalProgress?: number;
  caseStudyId?: ProjectId | null;
  caseStudyProgress?: MutableRefObject<number>;
}

/**
 * The single, coordinated 3D universe for the whole page. Hero, About,
 * Skills, Work, Journey, Certifications, Resume, and the case-study
 * environments all live in one Canvas/one render loop. When a case study is
 * open, the site-flow content (particles aside) scales to 0 and the
 * matching case-study environment scales to 1 — one continuous world, never
 * a second canvas.
 */
export default function Scene({
  scrollProgress,
  reducedMotion,
  isMobile = false,
  zoneOpacities,
  aboutLocalProgress = 0,
  journeyLocalProgress = 0,
  caseStudyId = null,
  caseStudyProgress,
}: SceneProps) {
  const simplify = reducedMotion || isMobile;
  const particleCount = reducedMotion ? 200 : isMobile ? 300 : 700;
  const siteFlowActive = !caseStudyId;

  return (
    <Canvas
      dpr={isMobile ? [1, 1] : [1, 1.5]}
      camera={{ position: [0, 0.2, 5], fov: 45 }}
      frameloop={reducedMotion ? "demand" : "always"}
      gl={{ antialias: !isMobile, alpha: true, powerPreference: "high-performance" }}
    >
      <color attach="background" args={["#050505"]} />
      <fog attach="fog" args={["#050505", 6, 16]} />
      <Suspense fallback={null}>
        <Lighting />
        <Particles count={particleCount} />

        <group visible={siteFlowActive}>
          <group scale={siteFlowActive ? zoneOpacities.hero : 0} visible={siteFlowActive && zoneOpacities.hero > 0.01}>
            <DigitalObjects simplify={simplify} />
            <AvatarModel />
          </group>

          <group scale={siteFlowActive ? zoneOpacities.about : 0} visible={siteFlowActive && zoneOpacities.about > 0.01}>
            <AboutTimeline3D localProgress={aboutLocalProgress} />
          </group>

          <group scale={siteFlowActive ? zoneOpacities.skills : 0} visible={siteFlowActive && zoneOpacities.skills > 0.01}>
            <SkillClusters3D />
          </group>

          <group scale={siteFlowActive ? zoneOpacities.work : 0} visible={siteFlowActive && zoneOpacities.work > 0.01}>
            <ProjectGallery3D />
          </group>

          <group scale={siteFlowActive ? zoneOpacities.journey : 0} visible={siteFlowActive && zoneOpacities.journey > 0.01}>
            <JourneyPath3D localProgress={journeyLocalProgress} />
          </group>

          <group
            scale={siteFlowActive ? zoneOpacities.certifications : 0}
            visible={siteFlowActive && zoneOpacities.certifications > 0.01}
          >
            <CertificationEnvironment3D />
          </group>

          <group scale={siteFlowActive ? zoneOpacities.resume : 0} visible={siteFlowActive && zoneOpacities.resume > 0.01}>
            <ResumeEnvironment3D />
          </group>

          <group scale={siteFlowActive ? zoneOpacities.contact : 0} visible={siteFlowActive && zoneOpacities.contact > 0.01}>
            <ContactEnvironment3D />
          </group>

          <group scale={siteFlowActive ? zoneOpacities.finalCta : 0} visible={siteFlowActive && zoneOpacities.finalCta > 0.01}>
            <FinalCTAEnvironment3D />
          </group>
        </group>

        <CaseStudyEnvironments3D activeId={caseStudyId} />

        <CameraRig
          scrollProgress={scrollProgress}
          reducedMotion={reducedMotion}
          caseStudyId={caseStudyId}
          caseStudyProgress={caseStudyProgress}
        />
      </Suspense>
    </Canvas>
  );
}
