"use client";

import { useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { useExperience } from "@/components/experience/ExperienceContext";

interface ClusterDef {
  id: string;
  position: [number, number, number];
  size: number;
  color: string;
}

// Growth is visually dominant (larger size, more central) per Muheeb's primary
// career direction; the other three orbit around it at a smaller scale.
const CLUSTERS: ClusterDef[] = [
  { id: "growth", position: [0, 1.1, -6.4], size: 0.55, color: "#D946EF" },
  { id: "web", position: [-1.7, -0.3, -6.9], size: 0.36, color: "#8B5CF6" },
  { id: "search", position: [1.8, -0.5, -6.6], size: 0.32, color: "#A855F7" },
  { id: "creative", position: [0, -1.7, -7.3], size: 0.34, color: "#A855F7" },
];

function ClusterNode({ id, position, size, color }: ClusterDef) {
  const { hoveredCluster } = useExperience();
  const ref = useRef<THREE.Mesh>(null);
  const isHovered = hoveredCluster === id;

  useFrame((state) => {
    if (!ref.current) return;
    const t = state.clock.getElapsedTime();
    ref.current.position.y = position[1] + Math.sin(t * 0.3 + position[0]) * 0.15;

    const targetScale = isHovered ? 1.25 : 1;
    ref.current.scale.setScalar(THREE.MathUtils.lerp(ref.current.scale.x, targetScale, 0.08));

    const material = ref.current.material as THREE.MeshStandardMaterial;
    material.emissiveIntensity = THREE.MathUtils.lerp(
      material.emissiveIntensity,
      isHovered ? 1.1 : 0.45,
      0.08
    );
  });

  return (
    <mesh ref={ref} position={position}>
      <icosahedronGeometry args={[size, 1]} />
      <meshStandardMaterial
        color="#0A0A0D"
        emissive={color}
        emissiveIntensity={0.45}
        metalness={0.7}
        roughness={0.25}
      />
    </mesh>
  );
}

/**
 * The 3D skill universe: a central hub with four orbiting cluster nodes
 * (Growth, Web, Search, Creative). Hover/focus state is read from
 * ExperienceContext, which the DOM skill cards in <SkillsSection /> write to
 * — so the 3D reacts to keyboard focus exactly like it reacts to mouse hover.
 */
export default function SkillClusters3D() {
  const groupRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (!groupRef.current) return;
    groupRef.current.rotation.y = state.clock.getElapsedTime() * 0.03;
  });

  return (
    <group ref={groupRef}>
      <mesh position={[0, -0.2, -6.8]}>
        <torusKnotGeometry args={[0.28, 0.08, 64, 8]} />
        <meshStandardMaterial
          color="#0A0A0D"
          emissive="#8B5CF6"
          emissiveIntensity={0.5}
          metalness={0.8}
          roughness={0.2}
        />
      </mesh>
      {CLUSTERS.map((c) => (
        <ClusterNode key={c.id} {...c} />
      ))}
    </group>
  );
}
