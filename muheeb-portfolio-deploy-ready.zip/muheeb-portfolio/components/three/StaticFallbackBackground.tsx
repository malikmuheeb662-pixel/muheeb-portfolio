/**
 * Graceful non-WebGL fallback: a static CSS gradient standing in for the 3D
 * digital universe, so the hero still looks intentional and on-brand for
 * browsers/devices where Canvas/WebGL isn't available.
 */
export default function StaticFallbackBackground() {
  return (
    <div className="absolute inset-0 overflow-hidden bg-[#050505]">
      <div className="absolute left-1/2 top-1/3 h-[60vmax] w-[60vmax] -translate-x-1/2 -translate-y-1/2 rounded-full bg-[#8B5CF6]/20 blur-[120px]" />
      <div className="absolute right-0 bottom-0 h-[40vmax] w-[40vmax] translate-x-1/4 translate-y-1/4 rounded-full bg-[#D946EF]/15 blur-[100px]" />
      <div
        className="absolute inset-0 opacity-[0.15]"
        style={{
          backgroundImage:
            "linear-gradient(rgba(168,85,247,0.3) 1px, transparent 1px), linear-gradient(90deg, rgba(168,85,247,0.3) 1px, transparent 1px)",
          backgroundSize: "60px 60px",
        }}
      />
    </div>
  );
}
