import { ReactNode } from "react";

export default function GlassPanel({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={`backdrop-blur-md bg-white/[0.03] border border-white/[0.08] rounded-2xl ${className}`}
    >
      {children}
    </div>
  );
}
