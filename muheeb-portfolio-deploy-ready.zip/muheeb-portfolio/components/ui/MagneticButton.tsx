"use client";

import { useRef } from "react";
import gsap from "gsap";

interface MagneticButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: "primary" | "secondary";
  className?: string;
  href?: string;
}

export default function MagneticButton({
  children,
  onClick,
  variant = "primary",
  className = "",
  href,
}: MagneticButtonProps) {
  const buttonRef = useRef<HTMLButtonElement>(null);
  const anchorRef = useRef<HTMLAnchorElement>(null);

  function animateTo(el: HTMLElement | null, x: number, y: number) {
    if (!el) return;
    gsap.to(el, { x, y, duration: 0.4, ease: "power2.out" });
  }

  function handleMouseMove(e: React.MouseEvent<HTMLElement>) {
    const el = e.currentTarget;
    const rect = el.getBoundingClientRect();
    const x = e.clientX - rect.left - rect.width / 2;
    const y = e.clientY - rect.top - rect.height / 2;
    animateTo(el, x * 0.25, y * 0.25);
  }

  function handleMouseLeave(e: React.MouseEvent<HTMLElement>) {
    gsap.to(e.currentTarget, { x: 0, y: 0, duration: 0.5, ease: "elastic.out(1, 0.4)" });
  }

  const base =
    "relative inline-flex items-center gap-2 px-7 py-3 text-sm tracking-widest font-medium rounded-full transition-colors duration-300 will-change-transform";
  const styles =
    variant === "primary"
      ? "bg-gradient-to-r from-[#8B5CF6] via-[#A855F7] to-[#D946EF] text-white shadow-[0_0_24px_rgba(168,85,247,0.35)] hover:shadow-[0_0_36px_rgba(168,85,247,0.55)]"
      : "border border-white/15 text-zinc-200 hover:border-white/30 hover:text-white";

  if (href) {
    return (
      <a
        ref={anchorRef}
        href={href}
        onClick={(e) => {
          if (onClick) {
            e.preventDefault();
            onClick();
          }
        }}
        onMouseMove={handleMouseMove}
        onMouseLeave={handleMouseLeave}
        className={`${base} ${styles} ${className}`}
      >
        {children}
      </a>
    );
  }

  return (
    <button
      ref={buttonRef}
      onClick={onClick}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      className={`${base} ${styles} ${className}`}
    >
      {children}
    </button>
  );
}
