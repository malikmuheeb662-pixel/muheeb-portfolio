export default function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex items-center gap-3 text-xs tracking-[0.3em] text-zinc-400 uppercase">
      <span className="h-px w-8 bg-gradient-to-r from-[#8B5CF6] to-transparent" />
      {children}
    </div>
  );
}
