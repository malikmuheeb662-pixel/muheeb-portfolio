"use client";

import { RefObject, useEffect, useState } from "react";

/**
 * Like useScrollProgress, but tracks scroll position within a specific
 * scrollable element instead of the window. Used by case study overlays,
 * whose internal content scrolls independently of the frozen background page.
 */
export function useElementScrollProgress(ref: RefObject<HTMLElement | null>) {
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;

    function handleScroll() {
      if (!el) return;
      const max = el.scrollHeight - el.clientHeight;
      setProgress(max > 0 ? el.scrollTop / max : 0);
    }

    el.addEventListener("scroll", handleScroll, { passive: true });
    handleScroll();
    return () => el.removeEventListener("scroll", handleScroll);
  }, [ref]);

  return progress;
}
