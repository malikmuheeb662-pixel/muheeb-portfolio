"use client";

import { useEffect, useRef } from "react";

/**
 * Tracks normalized mouse position (-1 to 1) for subtle parallax use in R3F scenes.
 */
export function useMouseParallax() {
  const target = useRef({ x: 0, y: 0 });

  useEffect(() => {
    function handleMove(e: MouseEvent) {
      target.current.x = (e.clientX / window.innerWidth) * 2 - 1;
      target.current.y = (e.clientY / window.innerHeight) * 2 - 1;
    }
    window.addEventListener("mousemove", handleMove, { passive: true });
    return () => window.removeEventListener("mousemove", handleMove);
  }, []);

  return target;
}
