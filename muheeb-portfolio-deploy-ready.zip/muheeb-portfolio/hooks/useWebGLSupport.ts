"use client";

import { useEffect, useState } from "react";

/**
 * Detects WebGL availability. Returns null until checked (client-only),
 * then true/false. Consumers should treat null as "checking" and avoid
 * flashing the fallback before the real answer is known.
 */
export function useWebGLSupport() {
  const [supported, setSupported] = useState<boolean | null>(null);

  useEffect(() => {
    try {
      const canvas = document.createElement("canvas");
      const gl =
        canvas.getContext("webgl2") ||
        canvas.getContext("webgl") ||
        canvas.getContext("experimental-webgl");
      // eslint-disable-next-line react-hooks/set-state-in-effect -- one-time synchronous capability probe on mount, not a subscription to changing external state
      setSupported(Boolean(gl));
    } catch {
      setSupported(false);
    }
  }, []);

  return supported;
}
