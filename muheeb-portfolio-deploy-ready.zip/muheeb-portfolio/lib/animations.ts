export const EASE = {
  premium: "power3.out",
  soft: "power2.inOut",
};

export const TRANSITION_DURATION = 2; // seconds, ENTER EXPERIENCE cinematic transition
