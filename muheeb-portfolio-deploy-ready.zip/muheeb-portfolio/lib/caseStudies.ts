export type ProjectId = "mubix-digital" | "didm-kalkaji" | "krypt";

export interface CaseStudyMediaSpec {
  kind: "image" | "gallery" | "video";
  count?: number;
  label?: string;
}

export interface CaseStudySection {
  id: string;
  label: string;
  heading: string;
  body: string;
  media: CaseStudyMediaSpec[];
}

export interface CaseStudyData {
  id: ProjectId;
  order: number;
  title: string;
  category: string;
  positioning: string;
  myRole: string;
  overviewHeading: string;
  overview: string;
  sections: CaseStudySection[];
  whatILearned: string[];
}

export const PROJECT_ORDER: ProjectId[] = ["mubix-digital", "didm-kalkaji", "krypt"];

export function getNextProjectId(id: ProjectId): ProjectId {
  const idx = PROJECT_ORDER.indexOf(id);
  return PROJECT_ORDER[(idx + 1) % PROJECT_ORDER.length];
}

export const CASE_STUDIES: Record<ProjectId, CaseStudyData> = {
  "mubix-digital": {
    id: "mubix-digital",
    order: 1,
    title: "MUBIX DIGITAL",
    category: "DIGITAL GROWTH / WEB / SEO / PAID TRAFFIC / CREATIVE",
    positioning:
      "A complete digital presence built from the ground up across web, search, paid traffic and creative production.",
    myRole:
      "I handled the complete digital execution — website design and development, SEO, Meta traffic campaigns, branding, creative production, content, AI-generated visuals and videos, and overall digital presentation.",
    overviewHeading: "THE PROJECT",
    overview:
      "Mubix Digital is my own digital marketing business project, built as a complete hands-on exercise in creating and managing a digital brand presence.",
    sections: [
      {
        id: "website",
        label: "WEBSITE",
        heading: "WEBSITE",
        body: "Designed and developed the digital presence from the ground up, with a focus on modern visual presentation, clear service communication and conversion-focused structure.",
        media: [{ kind: "gallery", count: 3, label: "ADD PROJECT SCREENSHOT" }],
      },
      {
        id: "seo",
        label: "SEO",
        heading: "SEO",
        body: "Worked on the website's SEO foundation and search visibility through on-page optimization and search-focused content structure.",
        media: [{ kind: "gallery", count: 2, label: "ADD PROJECT SCREENSHOT" }],
      },
      {
        id: "ads",
        label: "META ADS",
        heading: "META ADS",
        body: "Planned and launched a Meta traffic campaign, working through campaign objectives, audience targeting and creative execution.",
        media: [{ kind: "gallery", count: 3, label: "ADD PROJECT SCREENSHOT" }],
      },
      {
        id: "creative-ai",
        label: "CREATIVE + AI",
        heading: "CREATIVE + AI",
        body: "Created visual assets and content concepts using Canva, AI tools and video-editing workflows to support the brand and marketing activity.",
        media: [
          { kind: "gallery", count: 3, label: "ADD PROJECT SCREENSHOT" },
          { kind: "video", label: "PROJECT MEDIA" },
        ],
      },
    ],
    whatILearned: [
      "Connecting website and marketing thinking",
      "Understanding audience targeting",
      "Combining creative with paid traffic",
      "Building a consistent digital brand",
      "Executing across multiple digital channels",
    ],
  },

  "didm-kalkaji": {
    id: "didm-kalkaji",
    order: 2,
    title: "DIDM KALKAJI",
    category: "WEB DESIGN / DEVELOPMENT / EDUCATION",
    positioning:
      "A modern education-focused website experience designed and developed for the DIDM Kalkaji centre.",
    myRole:
      "Website design and development, including the visual system, page structure and digital presentation.",
    overviewHeading: "THE PROJECT",
    overview:
      "A modern education-focused website experience designed and developed for the DIDM Kalkaji centre.",
    sections: [
      {
        id: "website-experience",
        label: "WEBSITE EXPERIENCE",
        heading: "WEBSITE EXPERIENCE",
        body: "Designed and developed the website with a focus on clear course presentation, visual hierarchy and a conversion-oriented user journey.",
        media: [{ kind: "gallery", count: 3, label: "ADD PROJECT SCREENSHOT" }],
      },
      {
        id: "course-presentation",
        label: "COURSE PRESENTATION",
        heading: "COURSE PRESENTATION",
        body: "Structured the experience to make course information easier to explore while maintaining a clear path toward enquiry and action.",
        media: [{ kind: "gallery", count: 2, label: "ADD PROJECT SCREENSHOT" }],
      },
      {
        id: "ui-visual-design",
        label: "UI / VISUAL DESIGN",
        heading: "UI / VISUAL DESIGN",
        body: "Built a clean, modern visual system designed specifically for an education-focused digital experience.",
        media: [{ kind: "gallery", count: 3, label: "ADD PROJECT SCREENSHOT" }],
      },
    ],
    whatILearned: [
      "Presenting course information with clear visual hierarchy",
      "Structuring a conversion-oriented user journey for an education audience",
      "Building a clean visual system for an education-focused site",
    ],
  },

  krypt: {
    id: "krypt",
    order: 3,
    title: "KRYPT",
    category: "SHOPIFY / E-COMMERCE / SEO / CREATIVE",
    positioning:
      "A Shopify e-commerce experience focused on store design, customization, product presentation, creative assets and SEO.",
    myRole:
      "Shopify store design, theme customization/development, product listing and page creation, graphics/creative and SEO.",
    overviewHeading: "THE PROJECT",
    overview:
      "A Shopify e-commerce experience focused on store design, customization, product presentation, creative assets and SEO.",
    sections: [
      {
        id: "shopify-store",
        label: "SHOPIFY STORE",
        heading: "SHOPIFY STORE",
        body: "Designed and customized the Shopify storefront to create a structured and visually consistent shopping experience.",
        media: [{ kind: "gallery", count: 3, label: "ADD PROJECT SCREENSHOT" }],
      },
      {
        id: "product-experience",
        label: "PRODUCT EXPERIENCE",
        heading: "PRODUCT EXPERIENCE",
        body: "Worked on product presentation and page structure to make the catalog easier to browse and understand.",
        media: [{ kind: "gallery", count: 2, label: "ADD PROJECT SCREENSHOT" }],
      },
      {
        id: "creative",
        label: "CREATIVE",
        heading: "CREATIVE",
        body: "Created supporting visual assets and graphics for the e-commerce experience.",
        media: [{ kind: "gallery", count: 3, label: "ADD PROJECT SCREENSHOT" }],
      },
      {
        id: "seo",
        label: "SEO",
        heading: "SEO",
        body: "Worked on the store's SEO foundation as part of the overall e-commerce setup.",
        media: [{ kind: "gallery", count: 2, label: "ADD PROJECT SCREENSHOT" }],
      },
    ],
    whatILearned: [
      "Customizing a Shopify theme for a consistent storefront",
      "Structuring product pages for easier browsing",
      "Applying SEO fundamentals within an e-commerce setup",
    ],
  },
};
