export interface CertificationData {
  id: string;
  title: string;
  issuer: string | null;
  status: "confirmed" | "coming-soon";
  note?: string;
  imageSrc?: string;
  credentialUrl?: string;
}

export const CERTIFICATIONS: CertificationData[] = [
  {
    id: "openai",
    title: "OpenAI Certification",
    issuer: "OpenAI",
    status: "confirmed",
  },
  {
    id: "semrush",
    title: "Semrush Certification",
    issuer: "Semrush",
    status: "confirmed",
  },
  {
    id: "additional",
    title: "Additional Certification",
    issuer: null,
    status: "coming-soon",
    note: "Certification name to be confirmed.",
  },
];
