export const COLORS = {
  bgPrimary: "#050505",
  bgSecondary: "#0A0A0D",
  textPrimary: "#FFFFFF",
  textSecondary: "#A1A1AA",
  textMuted: "#71717A",
  purple1: "#8B5CF6",
  purple2: "#A855F7",
  purple3: "#D946EF",
};

export const NAV_ITEMS = [
  { label: "HOME", href: "#home", zone: "home" as const },
  { label: "ABOUT", href: "#about", zone: "about" as const },
  { label: "SKILLS", href: "#skills", zone: "skills" as const },
  { label: "WORK", href: "#work", zone: "work" as const },
  { label: "JOURNEY", href: "#journey", zone: "journey" as const },
  { label: "CERTIFICATIONS", href: "#certifications", zone: "certifications" as const },
  { label: "RESUME", href: "#resume", zone: "resume" as const },
  { label: "CONTACT", href: "#contact", zone: "contact" as const },
];

export const HERO_COPY = {
  eyebrow: "DIGITAL GROWTH & CREATIVE PROFESSIONAL",
  headline: "I BUILD DIGITAL EXPERIENCES THAT HELP BRANDS GROW.",
  supporting: "Web • SEO • Performance Marketing • Creative • E-Commerce",
  primaryCta: "EXPLORE MY WORK",
  secondaryCta: "VIEW RESUME",
};
