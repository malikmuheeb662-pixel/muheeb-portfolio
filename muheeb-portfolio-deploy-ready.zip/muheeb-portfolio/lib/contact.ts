export type ContactChannelId = "email" | "linkedin" | "whatsapp" | "instagram";

export interface ContactChannel {
  id: ContactChannelId;
  label: string;
  description: string;
  /** Raw value (email address, LinkedIn URL, WhatsApp number, Instagram handle/URL). Null until confirmed — never fabricate this. */
  value: string | null;
}

/**
 * Single source of truth for every contact channel. <ContactSection /> and
 * <Footer /> both read from here — never hard-code a duplicate value
 * elsewhere. Every value is null because no real contact detail has been
 * provided yet; fill these in once confirmed and every consumer updates
 * automatically.
 */
export const CONTACT_CHANNELS: ContactChannel[] = [
  {
    id: "email",
    label: "EMAIL",
    description: "Send a direct message.",
    value: null,
  },
  {
    id: "linkedin",
    label: "LINKEDIN",
    description: "Connect professionally.",
    value: null,
  },
  {
    id: "whatsapp",
    label: "WHATSAPP",
    description: "Message directly.",
    value: null,
  },
  {
    id: "instagram",
    label: "INSTAGRAM",
    description: "See creative work.",
    value: null,
  },
];

/** Builds the real href for a channel once its value is set; null while unconfirmed. */
export function getContactHref(channel: ContactChannel): string | null {
  if (!channel.value) return null;
  switch (channel.id) {
    case "email":
      return `mailto:${channel.value}`;
    case "whatsapp":
      return `https://wa.me/${channel.value.replace(/[^\d]/g, "")}`;
    case "linkedin":
    case "instagram":
      return channel.value;
    default:
      return null;
  }
}
