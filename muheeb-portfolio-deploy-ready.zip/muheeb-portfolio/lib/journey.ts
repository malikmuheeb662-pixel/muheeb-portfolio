export interface JourneyMilestoneData {
  id: string;
  order: number;
  label: string;
  title: string;
  subtitle: string;
}

export const JOURNEY_MILESTONES: JourneyMilestoneData[] = [
  {
    id: "bcom",
    order: 1,
    label: "01 / B.COM",
    title: "Bachelor of Commerce",
    subtitle: "School of Open Learning, University of Delhi",
  },
  {
    id: "mba",
    order: 2,
    label: "02 / MBA",
    title: "Master of Business Administration",
    subtitle: "IGNOU",
  },
  {
    id: "start",
    order: 3,
    label: "03 / 15 MAY 2026",
    title: "Started My Digital Marketing Journey",
    subtitle: "15 May 2026",
  },
  {
    id: "didm",
    order: 4,
    label: "04 / DIDM",
    title: "Digital Marketing Learning",
    subtitle: "DIDM",
  },
  {
    id: "projects",
    order: 5,
    label: "05 / REAL PROJECTS",
    title: "Hands-on Digital Projects",
    subtitle: "Mubix Digital, DIDM Kalkaji, Krypt",
  },
  {
    id: "focus",
    order: 6,
    label: "06 / CURRENT FOCUS",
    title: "Performance Marketing",
    subtitle:
      "Currently developing deeper expertise in Performance Marketing while building on my experience across web, SEO, e-commerce, paid traffic and creative production.",
  },
];
