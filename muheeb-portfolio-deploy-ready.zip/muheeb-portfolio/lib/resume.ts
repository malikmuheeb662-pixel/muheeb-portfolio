export const RESUME_EDUCATION = [
  { title: "B.Com", detail: "School of Open Learning, University of Delhi" },
  { title: "MBA", detail: "IGNOU" },
];

export const RESUME_LEARNING = { title: "DIDM", detail: "Started 15 May 2026" };

export const RESUME_CAPABILITIES = [
  "Website Design & Development",
  "SEO",
  "Meta Ads / Traffic Campaigns",
  "Shopify",
  "Video Editing",
  "Graphic Design",
  "AI Video Generation",
  "AI Graphic Design",
  "Content Shooting",
  "Creative Ideation",
];

export const RESUME_PROJECTS = ["Mubix Digital", "DIDM Kalkaji", "Krypt"];

/**
 * No resume file currently exists in this project. Set this to a real path
 * under /public (e.g. "/resume/muheeb-malik-resume.pdf") once one is added —
 * <ResumeSection /> will automatically switch the CTA from a "coming soon"
 * state to a real download link. Never fabricate a value here.
 */
export const RESUME_FILE_URL: string | null = null;
