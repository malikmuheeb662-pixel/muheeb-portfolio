/**
 * Shared scroll-zone math for the continuous Hero -> About -> Skills -> Work
 * -> Journey -> Certifications -> Resume -> Contact -> Final CTA 3D
 * experience. One tall scroll container, one pinned Canvas; these helpers
 * translate a single 0-1 page scroll fraction into per-zone opacities, local
 * progress within a zone, and camera keyframe timing.
 */

export const HERO_VH = 220;
export const ABOUT_VH = 240;
export const SKILLS_VH = 260;
export const WORK_VH = 320;
export const JOURNEY_VH = 260;
export const CERTS_VH = 200;
export const RESUME_VH = 200;
export const CONTACT_VH = 260;
export const FINAL_VH = 180;
export const TOTAL_VH =
  HERO_VH +
  ABOUT_VH +
  SKILLS_VH +
  WORK_VH +
  JOURNEY_VH +
  CERTS_VH +
  RESUME_VH +
  CONTACT_VH +
  FINAL_VH;

export const HERO_END = HERO_VH / TOTAL_VH;
export const ABOUT_END = (HERO_VH + ABOUT_VH) / TOTAL_VH;
export const SKILLS_END = (HERO_VH + ABOUT_VH + SKILLS_VH) / TOTAL_VH;
export const WORK_END = (HERO_VH + ABOUT_VH + SKILLS_VH + WORK_VH) / TOTAL_VH;
export const JOURNEY_END =
  (HERO_VH + ABOUT_VH + SKILLS_VH + WORK_VH + JOURNEY_VH) / TOTAL_VH;
export const CERTS_END =
  (HERO_VH + ABOUT_VH + SKILLS_VH + WORK_VH + JOURNEY_VH + CERTS_VH) / TOTAL_VH;
export const RESUME_END =
  (HERO_VH + ABOUT_VH + SKILLS_VH + WORK_VH + JOURNEY_VH + CERTS_VH + RESUME_VH) / TOTAL_VH;
export const CONTACT_END =
  (HERO_VH +
    ABOUT_VH +
    SKILLS_VH +
    WORK_VH +
    JOURNEY_VH +
    CERTS_VH +
    RESUME_VH +
    CONTACT_VH) /
  TOTAL_VH;

const FADE_BAND = 0.035;

function smoothstep(edge0: number, edge1: number, x: number) {
  const t = Math.min(1, Math.max(0, (x - edge0) / (edge1 - edge0)));
  return t * t * (3 - 2 * t);
}

export interface ZoneOpacities {
  hero: number;
  about: number;
  skills: number;
  work: number;
  journey: number;
  certifications: number;
  resume: number;
  contact: number;
  finalCta: number;
}

/** Crossfades between zones so there's never a hard section cut. */
export function computeZoneOpacities(progress: number): ZoneOpacities {
  const heroFade = smoothstep(HERO_END - FADE_BAND, HERO_END + FADE_BAND, progress);
  const aboutFade = smoothstep(ABOUT_END - FADE_BAND, ABOUT_END + FADE_BAND, progress);
  const skillsFade = smoothstep(SKILLS_END - FADE_BAND, SKILLS_END + FADE_BAND, progress);
  const workFade = smoothstep(WORK_END - FADE_BAND, WORK_END + FADE_BAND, progress);
  const journeyFade = smoothstep(JOURNEY_END - FADE_BAND, JOURNEY_END + FADE_BAND, progress);
  const certsFade = smoothstep(CERTS_END - FADE_BAND, CERTS_END + FADE_BAND, progress);
  const resumeFade = smoothstep(RESUME_END - FADE_BAND, RESUME_END + FADE_BAND, progress);
  const contactFade = smoothstep(CONTACT_END - FADE_BAND, CONTACT_END + FADE_BAND, progress);

  return {
    hero: 1 - heroFade,
    about: heroFade * (1 - aboutFade),
    skills: aboutFade * (1 - skillsFade),
    work: skillsFade * (1 - workFade),
    journey: workFade * (1 - journeyFade),
    certifications: journeyFade * (1 - certsFade),
    resume: certsFade * (1 - resumeFade),
    contact: resumeFade * (1 - contactFade),
    finalCta: contactFade,
  };
}

export function computeLocalProgress(progress: number, start: number, end: number) {
  return Math.min(1, Math.max(0, (progress - start) / (end - start || 1)));
}

export type ZoneName =
  | "home"
  | "about"
  | "skills"
  | "work"
  | "journey"
  | "certifications"
  | "resume"
  | "contact"
  | "final";

export function getZoneStartFraction(zone: ZoneName) {
  if (zone === "home") return 0;
  if (zone === "about") return HERO_END;
  if (zone === "skills") return ABOUT_END;
  if (zone === "work") return SKILLS_END;
  if (zone === "journey") return WORK_END;
  if (zone === "certifications") return JOURNEY_END;
  if (zone === "resume") return CERTS_END;
  if (zone === "contact") return RESUME_END;
  return CONTACT_END;
}

/** Programmatic nav: scrolls to the start of a zone within the single pinned experience. */
export function scrollToZone(zone: ZoneName) {
  if (typeof window === "undefined") return;
  const totalHeightPx = (TOTAL_VH / 100) * window.innerHeight;
  const targetY = getZoneStartFraction(zone) * totalHeightPx;
  window.scrollTo({ top: targetY, behavior: "smooth" });
}
